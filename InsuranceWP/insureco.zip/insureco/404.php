<?php get_header(); ?>
<section class="section"><div class="container narrow center">
	<h1>Page not found</h1>
	<p class="lead">The page you are looking for does not exist or has moved.</p>
	<p><a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go to homepage</a> <a class="btn btn-ghost" href="<?php echo esc_url( get_post_type_archive_link( 'insurance_product' ) ); ?>">Browse plans</a></p>
</div></section>
<?php get_footer(); ?>
