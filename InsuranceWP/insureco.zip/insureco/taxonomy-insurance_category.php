<?php
locate_template( 'archive-insurance_product.php', true, false );
