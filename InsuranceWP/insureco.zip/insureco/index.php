<?php get_header(); ?>
<?php get_template_part( 'template-parts/page-hero', null, array( 'title' => is_home() ? 'Latest updates' : ( is_search() ? 'Search results' : get_the_archive_title() ) ) ); ?>
<section class="section"><div class="container narrow prose">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<article class="post-item"><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article>
	<?php endwhile; the_posts_pagination(); else : ?>
		<div class="empty"><p>Nothing found.</p></div>
	<?php endif; ?>
</div></section>
<?php get_footer(); ?>
