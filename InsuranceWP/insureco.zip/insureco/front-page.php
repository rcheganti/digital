<?php get_header(); ?>

<section class="hero">
	<div class="container hero-grid">
		<div class="hero-copy">
			<p class="badge-pill"><?php echo ins_icon( 'shield-check', 18 ); // phpcs:ignore ?> Independent insurance advisors</p>
			<h1><?php echo esc_html( ins_opt( 'hero_title', 'Protect What Matters Most' ) ); ?></h1>
			<p class="hero-text"><?php echo esc_html( ins_opt( 'hero_text' ) ); ?></p>
			<div class="hero-actions">
				<a class="btn btn-primary btn-lg" href="<?php echo esc_url( ins_quote_url() ); ?>" data-open-quote><?php echo esc_html( ins_opt( 'cta_text', 'Get a Free Quote' ) ); ?></a>
				<a class="btn btn-ghost btn-lg" href="<?php echo esc_url( get_post_type_archive_link( 'insurance_product' ) ); ?>">Explore Plans</a>
			</div>
			<ul class="hero-checks">
				<li><?php echo ins_icon( 'check', 18 ); // phpcs:ignore ?> No hidden charges</li>
				<li><?php echo ins_icon( 'check', 18 ); // phpcs:ignore ?> Free expert advice</li>
				<li><?php echo ins_icon( 'check', 18 ); // phpcs:ignore ?> Quick response</li>
			</ul>
		</div>
		<div class="hero-art"><?php get_template_part( 'template-parts/hero-art' ); ?></div>
	</div>
</section>

<section class="stats" aria-label="Our numbers">
	<div class="container"><?php echo ins_render_stats(); // phpcs:ignore ?></div>
</section>

<section class="section">
	<div class="container">
		<div class="section-head">
			<h2>Insurance plans for every need</h2>
			<p>Choose a category or browse our most popular plans.</p>
		</div>
		<?php
		$cats = get_terms( array( 'taxonomy' => 'insurance_category', 'hide_empty' => true ) );
		if ( $cats && ! is_wp_error( $cats ) ) {
			echo '<ul class="cat-chips">';
			foreach ( $cats as $c ) {
				echo '<li><a class="chip" href="' . esc_url( get_term_link( $c ) ) . '">' . ins_icon( ins_category_icon( $c->slug ), 18 ) . esc_html( $c->name ) . '</a></li>'; // phpcs:ignore
			}
			echo '</ul>';
		}
		echo ins_render_products( array( 'limit' => 8, 'featured_first' => true ) ); // phpcs:ignore
		?>
		<p class="center"><a class="btn btn-ghost" href="<?php echo esc_url( get_post_type_archive_link( 'insurance_product' ) ); ?>">View all insurance plans</a></p>
	</div>
</section>

<section class="section section--alt">
	<div class="container">
		<div class="section-head">
			<h2>Why customers choose us</h2>
			<p>Honest advice, simple process and support that does not disappear after the sale.</p>
		</div>
		<?php get_template_part( 'template-parts/features' ); ?>
	</div>
</section>

<section class="section">
	<div class="container">
		<div class="section-head">
			<h2>How it works</h2>
			<p>From enquiry to cover in three simple steps.</p>
		</div>
		<ol class="steps">
			<li class="card"><span class="step-no">1</span><h3>Tell us what you need</h3><p>Fill in the short enquiry form. It takes about two minutes.</p></li>
			<li class="card"><span class="step-no">2</span><h3>Get expert recommendations</h3><p>Our advisor compares plans and calls you at your preferred time.</p></li>
			<li class="card"><span class="step-no">3</span><h3>Choose and get covered</h3><p>Pick the plan you like. We handle the paperwork and stay with you for claims.</p></li>
		</ol>
	</div>
</section>

<?php $t = ins_render_testimonials(); if ( $t ) : ?>
<section class="section section--alt">
	<div class="container">
		<div class="section-head"><h2>What our customers say</h2><p>Real families and business owners we have helped.</p></div>
		<?php echo $t; // phpcs:ignore ?>
	</div>
</section>
<?php endif; ?>

<section class="section">
	<div class="container narrow">
		<div class="section-head"><h2>Frequently asked questions</h2></div>
		<?php echo ins_render_faqs( array( 'limit' => 5 ) ); // phpcs:ignore ?>
		<p class="center"><a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">See all FAQs</a></p>
	</div>
</section>

<?php get_template_part( 'template-parts/cta-band' ); ?>
<?php get_footer(); ?>
