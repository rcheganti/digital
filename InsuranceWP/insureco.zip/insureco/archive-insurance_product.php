<?php
get_header();
$term  = is_tax( 'insurance_category' ) ? get_queried_object() : null;
$title = $term ? $term->name : 'Insurance Products';
$trail = array( 'Home' => home_url( '/' ) );
if ( $term ) {
	$trail['Insurance'] = get_post_type_archive_link( 'insurance_product' );
	$trail[ $term->name ] = '';
} else {
	$trail['Insurance'] = '';
}
get_template_part( 'template-parts/page-hero', null, array(
	'title' => $title,
	'lead'  => ( $term && $term->description ) ? $term->description : 'Compare plans, understand what is covered and get a free quote in minutes.',
	'trail' => $trail,
) );
?>
<section class="section">
	<div class="container">
		<?php
		$cats = get_terms( array( 'taxonomy' => 'insurance_category', 'hide_empty' => true ) );
		if ( $cats && ! is_wp_error( $cats ) ) :
			?>
			<ul class="cat-chips" aria-label="Filter by category">
				<li><a class="chip<?php echo $term ? '' : ' is-active'; ?>" href="<?php echo esc_url( get_post_type_archive_link( 'insurance_product' ) ); ?>">All plans</a></li>
				<?php foreach ( $cats as $c ) : ?>
					<li><a class="chip<?php echo ( $term && $term->term_id === $c->term_id ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_term_link( $c ) ); ?>"><?php echo ins_icon( ins_category_icon( $c->slug ), 18 ); // phpcs:ignore ?><?php echo esc_html( $c->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<?php if ( have_posts() ) : ?>
			<div class="cards">
				<?php
				while ( have_posts() ) {
					the_post();
					echo ins_render_product_card( get_the_ID() ); // phpcs:ignore
				}
				?>
			</div>
			<?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => 'Previous', 'next_text' => 'Next' ) ); ?>
		<?php else : ?>
			<div class="empty">
				<?php echo ins_icon( 'shield', 40 ); // phpcs:ignore ?>
				<h2>No plans in this category yet</h2>
				<p>New plans are added regularly. Meanwhile, our advisors can still help you find the right cover.</p>
				<a class="btn btn-primary" href="<?php echo esc_url( ins_quote_url() ); ?>" data-open-quote>Talk to an advisor</a>
			</div>
		<?php endif; ?>
	</div>
</section>
<?php get_template_part( 'template-parts/cta-band' ); ?>
<?php get_footer(); ?>
