(function () {
	'use strict';
	var d = document, root = d.documentElement;
	var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var header = d.getElementById('site-header');
	var toggle = d.querySelector('.nav-toggle');

	/* Sticky header shadow */
	var ticking = false;
	function onScroll() {
		if (ticking) return;
		ticking = true;
		requestAnimationFrame(function () {
			if (header) header.classList.toggle('is-scrolled', window.scrollY > 8);
			ticking = false;
		});
	}
	window.addEventListener('scroll', onScroll, { passive: true });
	onScroll();

	/* Mobile menu */
	function setNav(open) {
		if (!toggle) return;
		toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
		toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
		root.classList.toggle('nav-open', open);
	}
	if (toggle) {
		toggle.addEventListener('click', function () { setNav(toggle.getAttribute('aria-expanded') !== 'true'); });
		d.addEventListener('keydown', function (e) { if (e.key === 'Escape') setNav(false); });
		d.querySelectorAll('.primary-nav a').forEach(function (a) { a.addEventListener('click', function () { setNav(false); }); });
		window.matchMedia('(min-width: 961px)').addEventListener('change', function (m) { if (m.matches) setNav(false); });
	}

	/* Quote modal */
	var dlg = d.getElementById('ins-modal');
	d.addEventListener('click', function (e) {
		var t = e.target.closest('[data-open-quote]');
		if (t && dlg && typeof dlg.showModal === 'function') {
			e.preventDefault();
			setNav(false);
			if (window.InsEnquiry) window.InsEnquiry.prefill({ type: t.getAttribute('data-type') || '', product: t.getAttribute('data-product') || '' });
			dlg.showModal();
			root.classList.add('modal-open');
			return;
		}
		if (e.target.closest('[data-close-modal]') && dlg) dlg.close();
	});
	if (dlg) {
		dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
		dlg.addEventListener('close', function () { root.classList.remove('modal-open'); });
	}

	/* Accordion */
	d.addEventListener('click', function (e) {
		var b = e.target.closest('.acc-btn');
		if (!b) return;
		var open = b.getAttribute('aria-expanded') === 'true';
		b.setAttribute('aria-expanded', open ? 'false' : 'true');
		b.closest('.acc-item').classList.toggle('open', !open);
	});

	/* Testimonial carousel */
	d.querySelectorAll('[data-carousel]').forEach(function (c) {
		var track = c.querySelector('.carousel-track');
		c.querySelectorAll('.car-btn').forEach(function (b) {
			b.addEventListener('click', function () {
				var dir = parseInt(b.getAttribute('data-dir'), 10);
				track.scrollBy({ left: dir * track.clientWidth * 0.85, behavior: reduce ? 'auto' : 'smooth' });
			});
		});
	});

	/* Reveal on scroll + counters */
	function count(el) {
		var end = parseFloat(el.getAttribute('data-count'));
		var pre = el.getAttribute('data-prefix') || '', suf = el.getAttribute('data-suffix') || '';
		var dec = (el.getAttribute('data-count').split('.')[1] || '').length;
		var t0 = null, dur = 1100;
		function step(ts) {
			if (t0 === null) t0 = ts;
			var p = Math.min((ts - t0) / dur, 1), e = 1 - Math.pow(1 - p, 3);
			el.textContent = pre + (end * e).toFixed(dec) + suf;
			if (p < 1) requestAnimationFrame(step); else el.textContent = pre + end.toFixed(dec) + suf;
		}
		requestAnimationFrame(step);
	}
	var counters = [].slice.call(d.querySelectorAll('[data-count]'));
	if ('IntersectionObserver' in window && !reduce) {
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) {
				if (!en.isIntersecting) return;
				count(en.target);
				io.unobserve(en.target);
			});
		}, { threshold: 0.4 });
		counters.forEach(function (el) { io.observe(el); });
		var ro = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) {
				if (en.isIntersecting) { en.target.classList.add('is-visible'); ro.unobserve(en.target); }
			});
		}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
		d.querySelectorAll('.section-head, .feature-card, .steps .card, .stat, .t-card, .team-card, .cta-band').forEach(function (el) {
			el.classList.add('reveal');
			ro.observe(el);
		});
	}

	/* Keep floating buttons away from form fields on mobile */
	d.addEventListener('focusin', function (e) {
		if (e.target.matches('input,select,textarea') && window.innerWidth < 768) root.classList.add('hide-fab');
	});
	d.addEventListener('focusout', function () { root.classList.remove('hide-fab'); });
})();
