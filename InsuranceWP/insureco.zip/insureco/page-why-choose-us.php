<?php
get_header();
get_template_part( 'template-parts/page-hero', null, array(
	'title' => 'Why Choose Us',
	'lead'  => 'Insurance should feel clear and calm, not confusing. Here is how we make that happen.',
	'trail' => array( 'Home' => home_url( '/' ), 'Why Choose Us' => '' ),
) );
?>
<section class="section"><div class="container"><?php get_template_part( 'template-parts/features' ); ?></div></section>
<section class="stats stats--page"><div class="container"><?php echo ins_render_stats(); // phpcs:ignore ?></div></section>
<?php $t = ins_render_testimonials(); if ( $t ) : ?>
<section class="section"><div class="container"><div class="section-head"><h2>Loved by our customers</h2></div><?php echo $t; // phpcs:ignore ?></div></section>
<?php endif; ?>
<?php get_template_part( 'template-parts/cta-band' ); ?>
<?php get_footer(); ?>
