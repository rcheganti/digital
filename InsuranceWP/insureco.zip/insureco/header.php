<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#1d4fd7">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>

<div class="topbar">
	<div class="container topbar-inner">
		<span><?php echo ins_icon( 'clock', 16 ); // phpcs:ignore ?> <?php echo esc_html( ( ins_lines( ins_opt( 'hours' ) )[0] ?? '' ) ); ?></span>
		<span class="topbar-links">
			<a href="mailto:<?php echo esc_attr( ins_opt( 'email' ) ); ?>"><?php echo ins_icon( 'mail', 16 ); // phpcs:ignore ?> <?php echo esc_html( ins_opt( 'email' ) ); ?></a>
			<a href="<?php echo esc_attr( ins_tel() ); ?>"><?php echo ins_icon( 'phone', 16 ); // phpcs:ignore ?> <?php echo esc_html( ins_opt( 'phone' ) ); ?></a>
		</span>
	</div>
</div>

<header class="site-header" id="site-header">
	<div class="container header-inner">
		<?php echo insureco_logo(); // phpcs:ignore ?>
		<nav class="primary-nav" id="primary-nav" aria-label="Primary">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'menu',
				'fallback_cb'    => function () {
					echo '<ul class="menu"><li><a href="' . esc_url( home_url( '/' ) ) . '">Home</a></li><li><a href="' . esc_url( get_post_type_archive_link( 'insurance_product' ) ) . '">Insurance Products</a></li><li><a href="' . esc_url( ins_quote_url() ) . '">Contact</a></li></ul>';
				},
			) );
			?>
			<a class="btn btn-primary nav-cta-mobile" href="<?php echo esc_url( ins_quote_url() ); ?>" data-open-quote><?php echo esc_html( ins_opt( 'cta_text', 'Get a Free Quote' ) ); ?></a>
		</nav>
		<div class="header-actions">
			<a class="btn btn-primary btn-sm" href="<?php echo esc_url( ins_quote_url() ); ?>" data-open-quote>Get Quote</a>
			<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Open menu">
				<?php echo ins_icon( 'menu', 24, 'i-open' ); // phpcs:ignore ?><?php echo ins_icon( 'x', 24, 'i-close' ); // phpcs:ignore ?>
			</button>
		</div>
	</div>
</header>
<main id="main">
