</main>

<footer class="site-footer">
	<div class="container footer-grid">
		<div class="f-brand">
			<?php echo insureco_logo( 'brand--light' ); // phpcs:ignore ?>
			<p><?php echo esc_html( ins_opt( 'footer_text' ) ); ?></p>
			<?php echo ins_social_links(); // phpcs:ignore ?>
		</div>
		<div>
			<h2 class="f-title">Insurance</h2>
			<ul class="f-list">
				<?php
				$cats = get_terms( array( 'taxonomy' => 'insurance_category', 'hide_empty' => false, 'number' => 10 ) );
				if ( ! is_wp_error( $cats ) ) {
					foreach ( $cats as $c ) {
						echo '<li><a href="' . esc_url( get_term_link( $c ) ) . '">' . esc_html( $c->name ) . '</a></li>';
					}
				}
				?>
			</ul>
		</div>
		<div>
			<h2 class="f-title">Quick links</h2>
			<?php
			wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => 'f-list', 'depth' => 1, 'fallback_cb' => false ) );
			?>
		</div>
		<div>
			<h2 class="f-title">Contact</h2>
			<ul class="f-list f-contact">
				<?php if ( ins_opt( 'address' ) ) : ?><li><?php echo ins_icon( 'pin', 18 ); // phpcs:ignore ?><span><?php echo nl2br( esc_html( ins_opt( 'address' ) ) ); ?></span></li><?php endif; ?>
				<li><?php echo ins_icon( 'phone', 18 ); // phpcs:ignore ?><a href="<?php echo esc_attr( ins_tel() ); ?>"><?php echo esc_html( ins_opt( 'phone' ) ); ?></a></li>
				<?php if ( ins_wa_number() ) : ?><li><?php echo ins_icon( 'whatsapp', 18 ); // phpcs:ignore ?><a href="https://wa.me/<?php echo esc_attr( ins_wa_number() ); ?>" target="_blank" rel="noopener">Chat on WhatsApp</a></li><?php endif; ?>
				<li><?php echo ins_icon( 'mail', 18 ); // phpcs:ignore ?><a href="mailto:<?php echo esc_attr( ins_opt( 'email' ) ); ?>"><?php echo esc_html( ins_opt( 'email' ) ); ?></a></li>
				<?php if ( ins_opt( 'hours' ) ) : ?><li><?php echo ins_icon( 'clock', 18 ); // phpcs:ignore ?><span><?php echo nl2br( esc_html( ins_opt( 'hours' ) ) ); ?></span></li><?php endif; ?>
			</ul>
		</div>
	</div>
	<div class="container footer-bottom">
		<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( ins_opt( 'company_name' ) ); ?>. All rights reserved.</p>
		<p class="f-legal"><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy Policy</a><a href="<?php echo esc_url( home_url( '/terms-and-conditions/' ) ); ?>">Terms &amp; Conditions</a></p>
	</div>
</footer>

<div class="floating" aria-label="Quick contact">
	<?php if ( ins_wa_number() ) : ?>
		<a class="fab fab--wa" href="https://wa.me/<?php echo esc_attr( ins_wa_number() ); ?>" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"><?php echo ins_icon( 'whatsapp', 26 ); // phpcs:ignore ?></a>
	<?php endif; ?>
	<a class="fab fab--call" href="<?php echo esc_attr( ins_tel() ); ?>" aria-label="Call us"><?php echo ins_icon( 'phone', 24 ); // phpcs:ignore ?></a>
</div>

<?php if ( ! is_page( 'get-quote' ) ) : ?>
<dialog id="ins-modal" class="ins-modal" aria-labelledby="ins-modal-title">
	<div class="modal-card">
		<button type="button" class="modal-close" data-close-modal aria-label="Close"><?php echo ins_icon( 'x', 22 ); // phpcs:ignore ?></button>
		<h2 id="ins-modal-title">Get your free quote</h2>
		<p class="modal-sub">Four quick steps. No spam, no obligation.</p>
		<?php echo ins_render_form(); // phpcs:ignore ?>
	</div>
</dialog>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
