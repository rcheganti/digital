<?php
get_header();
while ( have_posts() ) :
	the_post();
	$id    = get_the_ID();
	$d     = ins_product_data( $id );
	$terms = get_the_terms( $id, 'insurance_category' );
	$cat   = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0] : null;
	$slug  = $cat ? $cat->slug : '';
	$cta   = get_post_meta( $id, '_ins_cta_text', true );
	$cta   = $cta ? $cta : 'Get a Quote';
	$kb    = get_post_meta( $id, '_ins_key_benefit', true );
	$trail = array( 'Home' => home_url( '/' ), 'Insurance' => get_post_type_archive_link( 'insurance_product' ) );
	if ( $cat ) {
		$trail[ $cat->name ] = get_term_link( $cat );
	}
	$trail[ get_the_title() ] = '';
	$sections = array(
		'benefits'    => array( 'Key benefits', 'check' ),
		'features'    => array( 'Features', 'check' ),
		'coverage'    => array( 'What is covered', 'shield-check' ),
		'eligibility' => array( 'Eligibility', 'users' ),
		'documents'   => array( 'Required documents', 'file' ),
	);
	?>
	<section class="page-hero page-hero--product">
		<div class="container">
			<?php echo insureco_breadcrumb( $trail ); // phpcs:ignore ?>
			<div class="product-hero">
				<div class="ph-copy">
					<?php if ( $cat ) : ?><a class="pc-cat" href="<?php echo esc_url( get_term_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a><?php endif; ?>
					<h1><?php the_title(); ?></h1>
					<p class="lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
					<?php if ( $kb ) : ?><p class="pc-benefit"><?php echo ins_icon( 'check', 20 ); // phpcs:ignore ?><span><?php echo esc_html( $kb ); ?></span></p><?php endif; ?>
					<div class="hero-actions">
						<a class="btn btn-primary btn-lg" href="<?php echo esc_url( ins_quote_url( $id, $slug ) ); ?>" data-open-quote data-product="<?php echo (int) $id; ?>" data-type="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $cta ); ?></a>
						<?php if ( ins_wa_number() ) : ?><a class="btn btn-ghost btn-lg" href="https://wa.me/<?php echo esc_attr( ins_wa_number() ); ?>?text=<?php echo rawurlencode( 'Hello, I would like to know more about ' . get_the_title() ); ?>" target="_blank" rel="noopener">Ask on WhatsApp</a><?php endif; ?>
					</div>
				</div>
				<div class="ph-media">
					<?php
					if ( has_post_thumbnail() ) {
						the_post_thumbnail( 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => get_the_title() ) );
					} else {
						echo '<span class="pc-icon pc-icon--lg">' . ins_icon( ins_category_icon( $slug ), 72 ) . '</span>'; // phpcs:ignore
					}
					?>
				</div>
			</div>
		</div>
	</section>

	<section class="section">
		<div class="container pd-grid">
			<div class="pd-main">
				<?php if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
					<div class="card section-card prose"><h2>About this plan</h2><?php the_content(); ?></div>
				<?php endif; ?>
				<?php foreach ( $sections as $key => $s ) : if ( empty( $d[ $key ] ) ) { continue; } ?>
					<div class="card section-card">
						<h2><?php echo esc_html( $s[0] ); ?></h2>
						<ul class="list-check">
							<?php foreach ( $d[ $key ] as $line ) : ?>
								<li><?php echo ins_icon( $s[1], 20 ); // phpcs:ignore ?><span><?php echo esc_html( $line ); ?></span></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>
				<?php if ( $d['faqs'] ) : ?>
					<div class="card section-card">
						<h2>Frequently asked questions</h2>
						<?php echo ins_render_accordion( $d['faqs'] ); // phpcs:ignore ?>
					</div>
				<?php endif; ?>
			</div>
			<aside class="pd-aside">
				<div class="card aside-card">
					<h2>Interested in this plan?</h2>
					<p>Get a free, no-obligation quote from an advisor.</p>
					<a class="btn btn-primary btn-block" href="<?php echo esc_url( ins_quote_url( $id, $slug ) ); ?>" data-open-quote data-product="<?php echo (int) $id; ?>" data-type="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $cta ); ?></a>
					<a class="aside-call" href="<?php echo esc_attr( ins_tel() ); ?>"><?php echo ins_icon( 'phone', 18 ); // phpcs:ignore ?> <?php echo esc_html( ins_opt( 'phone' ) ); ?></a>
				</div>
			</aside>
		</div>
	</section>

	<?php
	$rel = ins_get_products( array( 'limit' => 4, 'category' => $slug, 'exclude' => array( $id ) ) );
	if ( $rel ) :
		?>
		<section class="section section--alt">
			<div class="container">
				<div class="section-head"><h2>Related insurance plans</h2></div>
				<div class="cards"><?php foreach ( $rel as $rid ) { echo ins_render_product_card( $rid ); } // phpcs:ignore ?></div>
			</div>
		</section>
	<?php endif; ?>

	<div class="sticky-cta">
		<a class="btn btn-primary btn-block" href="<?php echo esc_url( ins_quote_url( $id, $slug ) ); ?>" data-open-quote data-product="<?php echo (int) $id; ?>" data-type="<?php echo esc_attr( $slug ); ?>">Get a Quote</a>
	</div>
<?php endwhile; ?>
<?php get_footer(); ?>
