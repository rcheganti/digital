<?php
get_header();
get_template_part( 'template-parts/page-hero', null, array(
	'title' => 'Frequently Asked Questions',
	'lead'  => 'Quick answers to the things people ask us most.',
	'trail' => array( 'Home' => home_url( '/' ), 'FAQ' => '' ),
) );
$cats = get_terms( array( 'taxonomy' => 'faq_category', 'hide_empty' => true ) );
?>
<section class="section">
	<div class="container narrow">
		<?php
		if ( $cats && ! is_wp_error( $cats ) && count( $cats ) > 1 ) {
			foreach ( $cats as $c ) {
				echo '<h2 class="faq-cat">' . esc_html( $c->name ) . '</h2>' . ins_render_faqs( array( 'category' => $c->slug, 'schema' => false ) ); // phpcs:ignore
			}
		} else {
			echo ins_render_faqs(); // phpcs:ignore
		}
		?>
	</div>
</section>
<?php get_template_part( 'template-parts/cta-band' ); ?>
<?php get_footer(); ?>
