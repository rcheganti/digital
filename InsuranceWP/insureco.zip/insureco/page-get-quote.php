<?php
get_header();
$type    = isset( $_GET['type'] ) ? sanitize_title( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$product = isset( $_GET['product'] ) ? absint( $_GET['product'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
get_template_part( 'template-parts/page-hero', null, array(
	'title' => 'Get your free quote',
	'lead'  => 'Four quick steps. Our advisor will contact you shortly.',
	'trail' => array( 'Home' => home_url( '/' ), 'Get a Quote' => '' ),
) );
?>
<section class="section">
	<div class="container narrow">
		<div class="card form-card"><?php echo ins_render_form( array( 'type' => $type, 'product' => $product ) ); // phpcs:ignore ?></div>
	</div>
</section>
<?php get_footer(); ?>
