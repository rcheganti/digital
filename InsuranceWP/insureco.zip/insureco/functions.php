<?php
defined( 'ABSPATH' ) || exit;

define( 'INSURECO_VER', '1.0.0' );

/* If the plugin is not active, keep the site from fatalling and tell the admin. */
if ( ! defined( 'INS_VER' ) ) {
	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-error"><p><strong>InsureCo theme:</strong> please activate the <em>Insurance Suite</em> plugin to enable products, leads and the enquiry form.</p></div>';
	} );
	function ins_opt( $k, $d = '' ) { return $d; }
	function ins_icon( $n = '', $s = 24, $c = '' ) { return ''; }
	function ins_quote_url( $p = 0, $t = '' ) { return home_url( '/get-quote/' ); }
	function ins_render_form( $a = array() ) { return ''; }
	function ins_render_products( $a = array() ) { return ''; }
	function ins_render_product_card( $id ) { return ''; }
	function ins_render_accordion( $i, $s = true ) { return ''; }
	function ins_render_faqs( $a = array() ) { return ''; }
	function ins_render_testimonials( $l = 12 ) { return ''; }
	function ins_render_team() { return ''; }
	function ins_render_stats() { return ''; }
	function ins_social_links() { return ''; }
	function ins_lines( $t ) { return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) $t ) ) ) ); }
	function ins_product_data( $id ) { return array( 'benefits' => array(), 'features' => array(), 'coverage' => array(), 'eligibility' => array(), 'documents' => array(), 'faqs' => array() ); }
	function ins_category_icon( $s ) { return 'shield'; }
	function ins_wa_number() { return ''; }
	function ins_tel() { return '#'; }
}

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 220, 'flex-width' => true, 'flex-height' => true ) );
	register_nav_menus( array( 'primary' => 'Primary menu', 'footer' => 'Footer quick links' ) );
	add_image_size( 'insureco-card', 640, 400, true );
	set_post_thumbnail_size( 1200, 800, true );
} );

// Serve WebP for newly uploaded JPEGs (WordPress 6.1+).
add_filter( 'image_editor_output_format', function ( $formats ) {
	$formats['image/jpeg'] = 'image/webp';
	return $formats;
} );

// Lean front-end: drop emoji and embed scripts.
add_action( 'init', function () {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'rsd_link' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	if ( ! file_exists( get_theme_file_path( "assets/css/main{$min}.css" ) ) ) {
		$min = '';
	}
	wp_enqueue_style( 'insureco', get_theme_file_uri( "assets/css/main{$min}.css" ), array(), INSURECO_VER );
	wp_enqueue_script( 'insureco', get_theme_file_uri( 'assets/js/main.js' ), array(), INSURECO_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
} );

/* ---------- Helpers used by templates ---------- */
function insureco_logo( $class = '' ) {
	$name = ins_opt( 'company_name', get_bloginfo( 'name' ) );
	$id   = (int) ins_opt( 'logo', 0 );
	$out  = '<a class="brand ' . esc_attr( $class ) . '" href="' . esc_url( home_url( '/' ) ) . '" aria-label="' . esc_attr( $name ) . ' home">';
	if ( $id ) {
		$out .= wp_get_attachment_image( $id, 'medium', false, array( 'class' => 'brand-img', 'alt' => $name, 'loading' => 'eager', 'decoding' => 'async' ) );
	} else {
		$out .= '<span class="brand-mark">' . ins_icon( 'shield-check', 22 ) . '</span><span class="brand-name">' . esc_html( $name ) . '</span>';
	}
	return $out . '</a>';
}

function insureco_breadcrumb( array $trail ) {
	$out = '<nav class="breadcrumb" aria-label="Breadcrumb"><ol>';
	$ld  = array();
	$n   = 0;
	foreach ( $trail as $label => $url ) {
		$n++;
		$last = ( $n === count( $trail ) );
		$out .= '<li>' . ( ( $url && ! $last ) ? '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>' : '<span aria-current="page">' . esc_html( $label ) . '</span>' ) . '</li>';
		$item = array( '@type' => 'ListItem', 'position' => $n, 'name' => $label );
		if ( $url ) {
			$item['item'] = $url;
		}
		$ld[] = $item;
	}
	$out .= '</ol></nav>';
	$out .= '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $ld ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>';
	return $out;
}

function insureco_features() {
	return array(
		array( 'shield-check', 'Trusted Guidance', 'Independent advisors who recommend what fits you, not what pays the highest commission.' ),
		array( 'layers', 'Multiple Insurance Options', 'Compare plans from leading insurers side by side across every major category.' ),
		array( 'zap', 'Easy Enquiry Process', 'A short four-step form. No long paperwork and no confusing jargon.' ),
		array( 'headset', 'Dedicated Support', 'One advisor who knows your case from the first call to the claim settlement.' ),
		array( 'eye', 'Transparent Information', 'Coverage, exclusions and costs explained clearly before you decide.' ),
		array( 'clock', 'Quick Response', 'We reach out within working hours, in the time slot you prefer.' ),
	);
}

/* ---------- Create pages, menu and front page on theme activation ---------- */
add_action( 'after_switch_theme', function () {
	$pages = array(
		'home'                 => array( 'Home', '' ),
		'about'                => array( 'About Us', '' ),
		'why-choose-us'        => array( 'Why Choose Us', '' ),
		'faq'                  => array( 'FAQ', '' ),
		'contact'              => array( 'Contact', '' ),
		'get-quote'            => array( 'Get a Quote', '' ),
		'privacy-policy'       => array( 'Privacy Policy', '<p>This is a placeholder. Replace it with your own privacy policy that explains what customer data you collect through the enquiry form, how it is used and how long it is kept.</p>' ),
		'terms-and-conditions' => array( 'Terms &amp; Conditions', '<p>This is a placeholder. Replace it with your own terms and conditions.</p>' ),
	);
	$ids = array();
	foreach ( $pages as $slug => $p ) {
		$ex = get_page_by_path( $slug );
		if ( $ex ) {
			if ( 'publish' !== $ex->post_status ) {
				wp_update_post( array( 'ID' => $ex->ID, 'post_status' => 'publish' ) );
			}
			$ids[ $slug ] = $ex->ID;
		} else {
			$ids[ $slug ] = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => html_entity_decode( $p[0] ), 'post_name' => $slug, 'post_content' => $p[1] ) );
		}
	}
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $ids['home'] );

	$locations = get_theme_mod( 'nav_menu_locations', array() );
	if ( empty( $locations['primary'] ) ) {
		$mid = wp_create_nav_menu( 'InsureCo Primary' );
		if ( ! is_wp_error( $mid ) ) {
			$items = array(
				array( 'Home', home_url( '/' ) ),
				array( 'About', get_permalink( $ids['about'] ) ),
				array( 'Insurance Products', home_url( '/insurance/' ) ),
				array( 'Why Choose Us', get_permalink( $ids['why-choose-us'] ) ),
				array( 'FAQ', get_permalink( $ids['faq'] ) ),
				array( 'Contact', get_permalink( $ids['contact'] ) ),
			);
			foreach ( $items as $i => $it ) {
				wp_update_nav_menu_item( $mid, 0, array( 'menu-item-title' => $it[0], 'menu-item-url' => $it[1], 'menu-item-status' => 'publish', 'menu-item-type' => 'custom', 'menu-item-position' => $i + 1 ) );
			}
			$locations['primary'] = $mid;
			$locations['footer']  = $mid;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}
	flush_rewrite_rules();
} );

// Current-menu highlighting for the product archive/single pages.
add_filter( 'nav_menu_css_class', function ( $classes, $item ) {
	if ( ( is_post_type_archive( 'insurance_product' ) || is_singular( 'insurance_product' ) || is_tax( 'insurance_category' ) ) && untrailingslashit( $item->url ) === untrailingslashit( home_url( '/insurance' ) ) ) {
		$classes[] = 'current-menu-item';
	}
	return $classes;
}, 10, 2 );

add_filter( 'body_class', function ( $c ) {
	if ( is_page( 'get-quote' ) ) {
		$c[] = 'page-get-quote';
	}
	if ( is_singular( 'insurance_product' ) ) {
		$c[] = 'has-sticky-cta';
	}
	return $c;
} );

add_filter( 'excerpt_length', function () { return 28; } );
add_filter( 'excerpt_more', function () { return '…'; } );
