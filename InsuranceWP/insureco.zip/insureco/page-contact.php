<?php
get_header();
get_template_part( 'template-parts/page-hero', null, array(
	'title' => 'Contact Us',
	'lead'  => 'Talk to an insurance advisor. We usually respond within working hours.',
	'trail' => array( 'Home' => home_url( '/' ), 'Contact' => '' ),
) );
?>
<section class="section">
	<div class="container contact-grid">
		<div class="contact-info">
			<div class="card info-card"><span class="f-icon"><?php echo ins_icon( 'phone', 24 ); // phpcs:ignore ?></span><div><h2>Call us</h2><a href="<?php echo esc_attr( ins_tel() ); ?>"><?php echo esc_html( ins_opt( 'phone' ) ); ?></a></div></div>
			<?php if ( ins_wa_number() ) : ?><div class="card info-card"><span class="f-icon"><?php echo ins_icon( 'whatsapp', 24 ); // phpcs:ignore ?></span><div><h2>WhatsApp</h2><a href="https://wa.me/<?php echo esc_attr( ins_wa_number() ); ?>" target="_blank" rel="noopener">Start a chat</a></div></div><?php endif; ?>
			<div class="card info-card"><span class="f-icon"><?php echo ins_icon( 'mail', 24 ); // phpcs:ignore ?></span><div><h2>Email</h2><a href="mailto:<?php echo esc_attr( ins_opt( 'email' ) ); ?>"><?php echo esc_html( ins_opt( 'email' ) ); ?></a></div></div>
			<div class="card info-card"><span class="f-icon"><?php echo ins_icon( 'pin', 24 ); // phpcs:ignore ?></span><div><h2>Visit us</h2><p><?php echo nl2br( esc_html( ins_opt( 'address' ) ) ); ?></p></div></div>
			<div class="card info-card"><span class="f-icon"><?php echo ins_icon( 'clock', 24 ); // phpcs:ignore ?></span><div><h2>Business hours</h2><p><?php echo nl2br( esc_html( ins_opt( 'hours' ) ) ); ?></p></div></div>
		</div>
		<div class="card form-card">
			<h2>Send us an enquiry</h2>
			<?php echo ins_render_form(); // phpcs:ignore ?>
		</div>
	</div>
</section>
<?php get_footer(); ?>
