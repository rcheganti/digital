<?php get_header(); ?>
<?php while ( have_posts() ) : the_post(); ?>
	<?php get_template_part( 'template-parts/page-hero', null, array( 'trail' => array( 'Home' => home_url( '/' ), get_the_title() => '' ) ) ); ?>
	<section class="section"><div class="container narrow prose"><?php the_content(); ?></div></section>
<?php endwhile; ?>
<?php get_footer(); ?>
