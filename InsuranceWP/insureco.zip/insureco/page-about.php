<?php
get_header();
get_template_part( 'template-parts/page-hero', null, array(
	'title' => 'About ' . ins_opt( 'company_name' ),
	'lead'  => ins_opt( 'tagline' ),
	'trail' => array( 'Home' => home_url( '/' ), 'About Us' => '' ),
) );
?>
<section class="section">
	<div class="container narrow">
		<div class="section-head left"><h2>Who we are</h2></div>
		<div class="prose"><p class="lead"><?php echo esc_html( ins_opt( 'about_intro' ) ); ?></p>
		<?php while ( have_posts() ) { the_post(); the_content(); } ?></div>
	</div>
</section>
<section class="section section--alt">
	<div class="container two-col">
		<div class="card mission-card"><span class="f-icon"><?php echo ins_icon( 'zap', 26 ); // phpcs:ignore ?></span><h2>Our mission</h2><p><?php echo esc_html( ins_opt( 'mission' ) ); ?></p></div>
		<div class="card mission-card"><span class="f-icon"><?php echo ins_icon( 'eye', 26 ); // phpcs:ignore ?></span><h2>Our vision</h2><p><?php echo esc_html( ins_opt( 'vision' ) ); ?></p></div>
	</div>
</section>
<section class="stats stats--page"><div class="container"><?php echo ins_render_stats(); // phpcs:ignore ?></div></section>
<section class="section">
	<div class="container">
		<div class="section-head"><h2>Why customers trust us</h2></div>
		<?php get_template_part( 'template-parts/features' ); ?>
	</div>
</section>
<?php $team = ins_render_team(); if ( $team ) : ?>
<section class="section section--alt">
	<div class="container">
		<div class="section-head"><h2>Meet the team</h2><p>The people who will guide you.</p></div>
		<?php echo $team; // phpcs:ignore ?>
	</div>
</section>
<?php endif; ?>
<?php get_template_part( 'template-parts/cta-band' ); ?>
<?php get_footer(); ?>
