<div class="features">
	<?php foreach ( insureco_features() as $f ) : ?>
		<div class="card feature-card">
			<span class="f-icon"><?php echo ins_icon( $f[0], 26 ); // phpcs:ignore ?></span>
			<h3><?php echo esc_html( $f[1] ); ?></h3>
			<p><?php echo esc_html( $f[2] ); ?></p>
		</div>
	<?php endforeach; ?>
</div>
