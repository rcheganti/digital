<svg class="hero-svg" viewBox="0 0 520 460" role="img" aria-label="Illustration of a protective shield over a happy family" xmlns="http://www.w3.org/2000/svg">
	<defs>
		<linearGradient id="hg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2f66ff"/><stop offset="1" stop-color="#173ea8"/></linearGradient>
		<linearGradient id="hg2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8efff"/><stop offset="1" stop-color="#f7faff"/></linearGradient>
	</defs>
	<rect x="40" y="40" width="440" height="380" rx="44" fill="url(#hg2)"/>
	<circle cx="420" cy="96" r="54" fill="#d6e3ff"/>
	<circle cx="96" cy="372" r="38" fill="#cdeedd"/>
	<path d="M260 88 394 134v100c0 84-58 136-134 168-76-32-134-84-134-168V134z" fill="url(#hg1)"/>
	<path d="M260 118 366 154v80c0 66-44 108-106 136-62-28-106-70-106-136v-80z" fill="#fff" fill-opacity=".1"/>
	<path d="m206 244 38 38 74-82" fill="none" stroke="#fff" stroke-width="22" stroke-linecap="round" stroke-linejoin="round"/>
	<g class="hero-float hero-float--a">
		<rect x="36" y="150" width="170" height="64" rx="18" fill="#fff"/>
		<circle cx="70" cy="182" r="16" fill="#dff5e8"/><path d="m62 182 6 6 12-13" fill="none" stroke="#0e9f6e" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
		<rect x="98" y="168" width="84" height="9" rx="4.5" fill="#0f1b2d"/><rect x="98" y="186" width="58" height="8" rx="4" fill="#b7c3d8"/>
	</g>
	<g class="hero-float hero-float--b">
		<rect x="318" y="316" width="168" height="64" rx="18" fill="#fff"/>
		<circle cx="352" cy="348" r="16" fill="#ffe3e3"/><path d="M352 357s-9-5-9-11a5 5 0 0 1 9-3 5 5 0 0 1 9 3c0 6-9 11-9 11z" fill="#e5484d"/>
		<rect x="380" y="334" width="80" height="9" rx="4.5" fill="#0f1b2d"/><rect x="380" y="352" width="54" height="8" rx="4" fill="#b7c3d8"/>
	</g>
</svg>
