<section class="section">
	<div class="container">
		<div class="cta-band">
			<div>
				<h2>Ready to protect what matters?</h2>
				<p>Tell us what you need and an insurance advisor will get back to you shortly, free of charge.</p>
			</div>
			<div class="cta-actions">
				<a class="btn btn-light" href="<?php echo esc_url( ins_quote_url() ); ?>" data-open-quote><?php echo esc_html( ins_opt( 'cta_text', 'Get a Free Quote' ) ); ?></a>
				<?php if ( ins_wa_number() ) : ?>
					<a class="btn btn-outline-light" href="https://wa.me/<?php echo esc_attr( ins_wa_number() ); ?>" target="_blank" rel="noopener"><?php echo ins_icon( 'whatsapp', 20 ); // phpcs:ignore ?> WhatsApp us</a>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
