<?php
$args = wp_parse_args( isset( $args ) ? $args : array(), array( 'title' => get_the_title(), 'lead' => '', 'trail' => array() ) );
?>
<section class="page-hero">
	<div class="container">
		<?php
		if ( $args['trail'] ) {
			echo insureco_breadcrumb( $args['trail'] ); // phpcs:ignore
		}
		?>
		<h1><?php echo esc_html( $args['title'] ); ?></h1>
		<?php if ( $args['lead'] ) : ?><p class="lead"><?php echo esc_html( $args['lead'] ); ?></p><?php endif; ?>
	</div>
</section>
