<?php
/**
 * Plugin Name:       Insurance Suite
 * Description:       Insurance products, categories, FAQs, testimonials, team, multi-step enquiry form, secure lead management (CRM-lite), dashboard, CSV/Excel export, email + WhatsApp notifications and a central settings page. Pair it with the "InsureCo" theme.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Your Company
 * License:           GPL-2.0-or-later
 * Text Domain:       insurance-suite
 */
defined( 'ABSPATH' ) || exit;

define( 'INS_VER', '1.0.0' );
define( 'INS_DIR', plugin_dir_path( __FILE__ ) );
define( 'INS_URL', plugin_dir_url( __FILE__ ) );

foreach ( array( 'helpers', 'cpt', 'leads-db', 'render', 'form', 'seo', 'admin-settings', 'admin-leads', 'admin-dashboard', 'export', 'seed' ) as $ins_file ) {
	require_once INS_DIR . 'includes/' . $ins_file . '.php';
}

register_activation_hook( __FILE__, 'ins_activate' );
function ins_activate() {
	ins_register_types();
	ins_install_db();
	ins_add_roles();
	if ( ! get_option( 'ins_seeded' ) ) {
		ins_seed();
		update_option( 'ins_seeded', 1 );
	}
	update_option( 'ins_db_ver', INS_VER );
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

// Run upgrades (DB / capabilities) when the plugin files are updated.
add_action( 'plugins_loaded', function () {
	if ( get_option( 'ins_db_ver' ) !== INS_VER ) {
		ins_install_db();
		ins_add_roles();
		update_option( 'ins_db_ver', INS_VER );
	}
} );
