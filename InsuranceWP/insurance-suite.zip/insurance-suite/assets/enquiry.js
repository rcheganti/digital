(function () {
	'use strict';
	var cfg = window.InsCfg || {};
	var norm = function (v) {
		v = (v || '').replace(/\D/g, '');
		if (v.length === 12 && v.indexOf('91') === 0) v = v.slice(2);
		if (v.length === 11 && v.charAt(0) === '0') v = v.slice(1);
		return v;
	};
	var RULES = {
		full_name: function (v) { return v.trim().length >= 2 || 'Please enter your full name.'; },
		mobile: function (v) { return /^[6-9]\d{9}$/.test(norm(v)) || 'Enter a valid 10-digit Indian mobile number.'; },
		email: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Enter a valid email address.'; },
		dob: function (v) { return !v || new Date(v) < new Date() || 'Date of birth must be in the past.'; },
		city: function (v) { return v.trim().length >= 2 || 'Please enter your city.'; },
		state: function (v) { return !!v || 'Please select your state.'; },
		pincode: function (v) { return /^[1-9]\d{5}$/.test(v.trim()) || 'Enter a valid 6-digit pincode.'; },
		insurance_type: function (v) { return !!v || 'Please choose an insurance type.'; },
		contact_method: function (v) { return !!v || 'Please choose how we should contact you.'; }
	};
	var forms = [];

	function init(form) {
		var steps = [].slice.call(form.querySelectorAll('.ins-step'));
		var prog = [].slice.call(form.querySelectorAll('.ins-progress li'));
		var done = form.querySelector('.ins-done');
		var back = form.querySelector('[data-back]');
		var next = form.querySelector('[data-next]');
		var submit = form.querySelector('[data-submit]');
		var status = form.querySelector('.ins-status');
		var typeSel = form.elements.insurance_type;
		var prodSel = form.elements.product_id;
		var policyWrap = form.querySelector('.is-policy');
		var cur = 0;
		var allProducts = [].slice.call(prodSel.options).slice(1).map(function (o) {
			return { v: o.value, t: o.textContent, c: (o.getAttribute('data-cat') || '').split(' ') };
		});

		function show(i, focus) {
			cur = i;
			steps.forEach(function (s, k) { s.hidden = k !== i; });
			prog.forEach(function (p, k) {
				p.classList.toggle('is-current', k === i);
				p.classList.toggle('is-done', k < i);
				if (k === i) p.setAttribute('aria-current', 'step'); else p.removeAttribute('aria-current');
			});
			back.hidden = i === 0;
			next.hidden = i === steps.length - 1;
			submit.hidden = i !== steps.length - 1;
			status.textContent = '';
			if (focus) {
				var lg = steps[i].querySelector('legend');
				if (lg) lg.focus({ preventScroll: true });
				var top = form.getBoundingClientRect().top;
				if (top < 0) form.scrollIntoView({ block: 'start' });
			}
		}

		function wrapOf(name) { return form.querySelector('[data-field="' + name + '"]'); }
		function setErr(name, msg) {
			var w = wrapOf(name);
			if (!w) return;
			var e = w.querySelector('.ins-error');
			var inp = w.querySelector('input,select,textarea');
			if (e) e.textContent = msg || '';
			w.classList.toggle('has-error', !!msg);
			if (inp) {
				if (msg) { inp.setAttribute('aria-invalid', 'true'); if (e && e.id) inp.setAttribute('aria-describedby', e.id); }
				else { inp.removeAttribute('aria-invalid'); }
			}
		}
		function check(name) {
			var el = form.elements[name];
			if (!el) return true;
			var res;
			if (name === 'consent') res = el.checked || 'Please tick the consent box so we can contact you.';
			else if (RULES[name]) res = RULES[name](el.value || '');
			else return true;
			setErr(name, res === true ? '' : res);
			return res === true;
		}
		function validStep(i) {
			var bad = null;
			[].slice.call(steps[i].querySelectorAll('[data-field]')).forEach(function (w) {
				if (!check(w.getAttribute('data-field')) && !bad) bad = w;
			});
			if (bad) {
				var inp = bad.querySelector('input,select,textarea');
				if (inp) inp.focus();
				return false;
			}
			return true;
		}

		function rebuildProducts(keep) {
			var t = typeSel.value;
			var cur = keep !== undefined ? keep : prodSel.value;
			var html = '<option value="">Not sure / advisor to suggest</option>';
			allProducts.forEach(function (p) {
				if (!t || p.c.indexOf(t) > -1) html += '<option value="' + p.v + '" data-cat="' + p.c.join(' ') + '">' + p.t.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</option>';
			});
			prodSel.innerHTML = html;
			prodSel.value = cur;
			if (prodSel.value !== String(cur)) prodSel.value = '';
		}
		function togglePolicy() {
			var yes = form.querySelector('input[name="existing_policy"]:checked');
			if (policyWrap) policyWrap.hidden = !(yes && yes.value === 'Yes');
		}

		typeSel.addEventListener('change', function () { rebuildProducts(); check('insurance_type'); });
		prodSel.addEventListener('change', function () {
			if (prodSel.value && !typeSel.value) {
				var p = allProducts.filter(function (x) { return x.v === prodSel.value; })[0];
				if (p && p.c[0]) { typeSel.value = p.c[0]; setErr('insurance_type', ''); }
			}
		});
		form.addEventListener('change', function (e) { if (e.target.name === 'existing_policy') togglePolicy(); });
		form.addEventListener('focusout', function (e) {
			var n = e.target.name;
			if (n && (RULES[n] || n === 'consent') && (e.target.value || e.target.closest('.has-error'))) check(n);
		});
		form.addEventListener('input', function (e) {
			var n = e.target.name;
			if (n === 'pincode' || n === 'mobile') e.target.value = e.target.value.replace(/[^\d +]/g, '');
			if (n && e.target.closest('.has-error')) check(n);
		});
		back.addEventListener('click', function () { show(cur - 1, true); });
		next.addEventListener('click', function () { if (validStep(cur)) show(cur + 1, true); });

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			if (cur < steps.length - 1) { if (validStep(cur)) show(cur + 1, true); return; }
			for (var i = 0; i < steps.length; i++) {
				if (!validStep(i)) { show(i, false); validStep(i); return; }
			}
			submit.disabled = true;
			submit.classList.add('is-loading');
			status.textContent = 'Submitting your enquiry...';
			var fd = new FormData(form);
			fd.set('action', 'ins_submit_enquiry');
			fetch(cfg.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					submit.disabled = false;
					submit.classList.remove('is-loading');
					if (res && res.success) {
						form.classList.add('is-done');
						prog.forEach(function (p) { p.classList.remove('is-current'); p.classList.add('is-done'); });
						prog[prog.length - 1].setAttribute('aria-current', 'step');
						done.querySelector('[data-lead-id]').textContent = res.data.lead_code;
						var wa = done.querySelector('[data-wa]');
						if (res.data.whatsapp) { wa.href = res.data.whatsapp; wa.hidden = false; } else { wa.hidden = true; }
						done.hidden = false;
						form.querySelector('.ins-body').hidden = true;
						done.focus();
						status.textContent = '';
						return;
					}
					var d = (res && res.data) || {};
					if (d.errors) {
						var first = null;
						Object.keys(d.errors).forEach(function (k) { setErr(k, d.errors[k]); if (!first) first = k; });
						var w = first && wrapOf(first);
						if (w) { show(steps.indexOf(w.closest('.ins-step')), false); var inp = w.querySelector('input,select,textarea'); if (inp) inp.focus(); }
					}
					status.textContent = d.message || 'Something went wrong. Please try again.';
				})
				.catch(function () {
					submit.disabled = false;
					submit.classList.remove('is-loading');
					status.textContent = 'Network error. Please check your connection and try again.';
				});
		});

		function reset() {
			form.reset();
			form.classList.remove('is-done');
			done.hidden = true;
			form.querySelector('.ins-body').hidden = false;
			[].slice.call(form.querySelectorAll('.has-error')).forEach(function (w) { setErr(w.getAttribute('data-field'), ''); });
			rebuildProducts('');
			togglePolicy();
			show(0, false);
		}
		function prefill(o) {
			if (form.classList.contains('is-done')) reset();
			if (o.type) typeSel.value = o.type;
			rebuildProducts(o.product ? String(o.product) : '');
			if (o.product) {
				prodSel.value = String(o.product);
				if (!typeSel.value) prodSel.dispatchEvent(new Event('change'));
			}
			if (o.type !== undefined || o.product !== undefined) show(0, false);
		}
		togglePolicy();
		show(0, false);
		if (form.getAttribute('data-type') || form.getAttribute('data-product')) {
			prefill({ type: form.getAttribute('data-type'), product: form.getAttribute('data-product') !== '0' ? form.getAttribute('data-product') : '' });
		}
		forms.push({ el: form, prefill: prefill });
	}

	function boot() {
		[].slice.call(document.querySelectorAll('.ins-form')).forEach(init);
	}
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();

	window.InsEnquiry = {
		prefill: function (o) {
			var t = forms.filter(function (f) { return f.el.closest('#ins-modal'); })[0] || forms[0];
			if (t) t.prefill(o || {});
		}
	};
})();
