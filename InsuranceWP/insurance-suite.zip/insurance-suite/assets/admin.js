(function ($) {
	'use strict';
	// Product FAQ repeater
	$(document).on('click', '#ins-faq-add', function () {
		var tpl = document.getElementById('ins-faq-tpl');
		if (tpl) $('#ins-faq-rep').append(tpl.content.cloneNode(true));
	});
	$(document).on('click', '.ins-rep-del', function () { $(this).closest('.ins-rep-row').remove(); });
	// Media picker (settings)
	$(document).on('click', '.ins-media-pick', function (e) {
		e.preventDefault();
		var box = $(this).closest('.ins-media');
		var frame = wp.media({ title: 'Choose image', multiple: false, library: { type: 'image' } });
		frame.on('select', function () {
			var a = frame.state().get('selection').first().toJSON();
			box.find('input[type=hidden]').val(a.id);
			box.find('img').attr('src', (a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url)).prop('hidden', false);
		});
		frame.open();
	});
	$(document).on('click', '.ins-media-clear', function (e) {
		e.preventDefault();
		var box = $(this).closest('.ins-media');
		box.find('input[type=hidden]').val('0');
		box.find('img').prop('hidden', true).attr('src', '');
	});
})(jQuery);
