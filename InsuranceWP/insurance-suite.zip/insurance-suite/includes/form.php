<?php
defined( 'ABSPATH' ) || exit;

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_script( 'ins-enquiry', INS_URL . 'assets/enquiry.js', array(), INS_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_localize_script( 'ins-enquiry', 'InsCfg', array( 'ajax' => admin_url( 'admin-ajax.php' ) ) );
	if ( ins_opt( 'turnstile_site' ) ) {
		wp_enqueue_script( 'cf-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, array( 'strategy' => 'async', 'in_footer' => true ) ); // phpcs:ignore
	}
} );

/** Render the multi-step enquiry form. */
function ins_render_form( $a = array() ) {
	static $n = 0;
	$n++;
	$id   = 'insf' . $n;
	$a    = wp_parse_args( $a, array( 'type' => '', 'product' => 0 ) );
	$opts = ins_form_options();

	$in  = function ( $name, $type = 'text', $attrs = '' ) use ( $id ) {
		return '<input class="ins-input" type="' . $type . '" id="' . $id . '-' . $name . '" name="' . $name . '" ' . $attrs . '>';
	};
	$sel = function ( $name, $options, $attrs = '' ) use ( $id ) {
		$h = '<select class="ins-input" id="' . $id . '-' . $name . '" name="' . $name . '" ' . $attrs . '><option value="">Select</option>';
		foreach ( $options as $v => $l ) {
			$h .= '<option value="' . esc_attr( $v ) . '">' . esc_html( $l ) . '</option>';
		}
		return $h . '</select>';
	};
	$same = function ( $arr ) {
		return array_combine( $arr, $arr );
	};
	$fld = function ( $name, $label, $html, $req = false, $class = '' ) use ( $id ) {
		echo '<div class="ins-field ' . esc_attr( $class ) . '" data-field="' . esc_attr( $name ) . '"><label for="' . esc_attr( $id . '-' . $name ) . '">' . esc_html( $label ) . ( $req ? ' <span class="req" aria-hidden="true">*</span><span class="sr-only"> (required)</span>' : '' ) . '</label>' . $html . '<p class="ins-error" id="' . esc_attr( $id . '-' . $name ) . '-err" role="alert"></p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	};

	$types = array();
	foreach ( $opts['cats'] as $c ) {
		$types[ $c['slug'] ] = $c['name'];
	}
	$prod_html = '<select class="ins-input" id="' . $id . '-product_id" name="product_id"><option value="">Not sure / advisor to suggest</option>';
	foreach ( $opts['prods'] as $p ) {
		$prod_html .= '<option value="' . (int) $p['id'] . '" data-cat="' . esc_attr( implode( ' ', $p['cats'] ) ) . '">' . esc_html( $p['title'] ) . '</option>';
	}
	$prod_html .= '</select>';

	ob_start();
	?>
	<form class="ins-form" id="<?php echo esc_attr( $id ); ?>" method="post" novalidate data-type="<?php echo esc_attr( $a['type'] ); ?>" data-product="<?php echo (int) $a['product']; ?>">
		<ol class="ins-progress" aria-label="Enquiry progress">
			<?php foreach ( array( 'Personal', 'Location', 'Requirement', 'Contact', 'Done' ) as $i => $s ) : ?>
				<li<?php echo 0 === $i ? ' class="is-current"' : ''; ?>><span class="dot"><?php echo (int) ( $i + 1 ); ?></span><span class="lbl"><?php echo esc_html( $s ); ?></span></li>
			<?php endforeach; ?>
		</ol>

		<div class="ins-body">
			<fieldset class="ins-step" data-step="0">
				<legend tabindex="-1">Your personal details</legend>
				<div class="ins-grid">
					<?php
					$fld( 'full_name', 'Full name', $in( 'full_name', 'text', 'autocomplete="name" required' ), true, 'span-2' );
					$fld( 'mobile', 'Mobile number', $in( 'mobile', 'tel', 'autocomplete="tel-national" inputmode="numeric" maxlength="14" placeholder="98765 43210" required' ), true );
					$fld( 'email', 'Email', $in( 'email', 'email', 'autocomplete="email" required' ), true );
					$fld( 'dob', 'Date of birth', $in( 'dob', 'date', 'autocomplete="bday" max="' . esc_attr( gmdate( 'Y-m-d' ) ) . '"' ) );
					$fld( 'gender', 'Gender', $sel( 'gender', $same( array( 'Male', 'Female', 'Other', 'Prefer not to say' ) ) ) );
					?>
				</div>
			</fieldset>

			<fieldset class="ins-step" data-step="1" hidden>
				<legend tabindex="-1">Where do you live?</legend>
				<div class="ins-grid">
					<?php
					$fld( 'city', 'City', $in( 'city', 'text', 'autocomplete="address-level2" required' ), true );
					$fld( 'state', 'State', $sel( 'state', $same( ins_states() ), 'autocomplete="address-level1" required' ), true );
					$fld( 'pincode', 'Pincode', $in( 'pincode', 'text', 'autocomplete="postal-code" inputmode="numeric" maxlength="6" placeholder="500081" required' ), true );
					?>
				</div>
			</fieldset>

			<fieldset class="ins-step" data-step="2" hidden>
				<legend tabindex="-1">What cover do you need?</legend>
				<div class="ins-grid">
					<?php
					$fld( 'insurance_type', 'Insurance type', $sel( 'insurance_type', $types, 'required' ), true );
					$fld( 'product_id', 'Insurance product', $prod_html );
					?>
					<div class="ins-field span-2" data-field="existing_policy">
						<span class="ins-label" id="<?php echo esc_attr( $id ); ?>-ep-l">Do you have an existing policy?</span>
						<div class="ins-radios" role="radiogroup" aria-labelledby="<?php echo esc_attr( $id ); ?>-ep-l">
							<label class="ins-radio"><input type="radio" name="existing_policy" value="No" checked> No</label>
							<label class="ins-radio"><input type="radio" name="existing_policy" value="Yes"> Yes</label>
						</div>
						<p class="ins-error" role="alert"></p>
					</div>
					<?php
					$fld( 'policy_number', 'Policy number', $in( 'policy_number', 'text', 'maxlength="80" autocomplete="off"' ), false, 'span-2 is-policy' );
					$fld( 'coverage', 'Coverage required', $sel( 'coverage', $same( array( 'Up to ₹5 lakh', '₹5 to 10 lakh', '₹10 to 25 lakh', '₹25 to 50 lakh', '₹50 lakh to 1 crore', 'Above ₹1 crore', 'Not sure yet' ) ) ) );
					$fld( 'budget', 'Approximate yearly budget', $sel( 'budget', $same( array( 'Under ₹5,000', '₹5,000 to 10,000', '₹10,000 to 25,000', '₹25,000 to 50,000', 'Above ₹50,000', 'Flexible' ) ) ) );
					?>
				</div>
			</fieldset>

			<fieldset class="ins-step" data-step="3" hidden>
				<legend tabindex="-1">How should we reach you?</legend>
				<div class="ins-grid">
					<?php
					$fld( 'contact_method', 'Preferred contact method', $sel( 'contact_method', $same( array( 'Phone call', 'WhatsApp', 'Email' ) ), 'required' ), true );
					$fld( 'contact_time', 'Preferred contact time', $sel( 'contact_time', $same( array( 'Morning (9 am to 12 pm)', 'Afternoon (12 to 4 pm)', 'Evening (4 to 8 pm)', 'Anytime' ) ) ) );
					$fld( 'message', 'Additional requirements', '<textarea class="ins-input" id="' . esc_attr( $id ) . '-message" name="message" rows="3" maxlength="1000"></textarea>', false, 'span-2' );
					?>
					<div class="ins-field span-2" data-field="consent">
						<label class="ins-check"><input type="checkbox" name="consent" value="1" required id="<?php echo esc_attr( $id ); ?>-consent"> <span>I agree to be contacted by <?php echo esc_html( ins_opt( 'company_name' ) ); ?> about this enquiry and accept the <a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>" target="_blank" rel="noopener">Privacy Policy</a>.</span></label>
						<p class="ins-error" id="<?php echo esc_attr( $id ); ?>-consent-err" role="alert"></p>
					</div>
				</div>
				<?php if ( ins_opt( 'turnstile_site' ) ) : ?>
					<div class="cf-turnstile" data-sitekey="<?php echo esc_attr( ins_opt( 'turnstile_site' ) ); ?>"></div>
				<?php endif; ?>
			</fieldset>

			<div class="ins-hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
			<input type="hidden" name="_ins_nonce" value="<?php echo esc_attr( wp_create_nonce( 'ins_enquiry' ) ); ?>">
			<input type="hidden" name="ins_ts" value="<?php echo (int) time(); ?>">

			<p class="ins-status" role="status" aria-live="polite"></p>
			<div class="ins-actions">
				<button type="button" class="btn btn-ghost" data-back hidden>Back</button>
				<button type="button" class="btn btn-primary" data-next>Continue</button>
				<button type="submit" class="btn btn-primary" data-submit hidden><span>Submit Enquiry</span></button>
			</div>
		</div>

		<div class="ins-done" hidden tabindex="-1">
			<div class="done-icon"><?php echo ins_icon( 'check', 36 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<h3>Thank You!</h3>
			<p>Your enquiry has been submitted successfully. Our insurance advisor will contact you shortly.</p>
			<p class="done-id">Enquiry ID: <strong data-lead-id></strong></p>
			<div class="done-actions">
				<a class="btn btn-wa" data-wa href="#" target="_blank" rel="noopener"><?php echo ins_icon( 'whatsapp', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> Contact on WhatsApp</a>
				<a class="btn btn-ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go to Homepage</a>
			</div>
		</div>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'ins_enquiry_form', function () {
	$type    = isset( $_GET['type'] ) ? sanitize_title( wp_unslash( $_GET['type'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$product = isset( $_GET['product'] ) ? absint( $_GET['product'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	return ins_render_form( array( 'type' => $type, 'product' => $product ) );
} );

/* ---------- Submission ---------- */
add_action( 'wp_ajax_nopriv_ins_submit_enquiry', 'ins_ajax_submit' );
add_action( 'wp_ajax_ins_submit_enquiry', 'ins_ajax_submit' );

function ins_client_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

function ins_ajax_submit() {
	$nonce = isset( $_POST['_ins_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_ins_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'ins_enquiry' ) ) {
		wp_send_json_error( array( 'message' => 'Your session expired. Please refresh the page and try again.' ), 403 );
	}
	// Honeypot: pretend success so bots learn nothing.
	if ( ! empty( $_POST['website'] ) ) {
		wp_send_json_success( array( 'lead_code' => 'INS-00000', 'whatsapp' => '' ) );
	}
	$ts = isset( $_POST['ins_ts'] ) ? absint( $_POST['ins_ts'] ) : 0;
	if ( ! $ts || ( time() - $ts ) < 3 ) {
		wp_send_json_error( array( 'message' => 'That was a little too quick. Please try again.' ), 429 );
	}
	$ip   = ins_client_ip();
	$rkey = 'ins_rl_' . md5( $ip );
	$hits = (int) get_transient( $rkey );
	if ( $hits >= 5 ) {
		wp_send_json_error( array( 'message' => 'Too many enquiries from your network. Please try again later or call us.' ), 429 );
	}
	// Optional Cloudflare Turnstile.
	if ( ins_opt( 'turnstile_secret' ) ) {
		$tok = isset( $_POST['cf-turnstile-response'] ) ? sanitize_text_field( wp_unslash( $_POST['cf-turnstile-response'] ) ) : '';
		$res = $tok ? wp_remote_post( 'https://challenges.cloudflare.com/turnstile/v0/siteverify', array( 'timeout' => 8, 'body' => array( 'secret' => ins_opt( 'turnstile_secret' ), 'response' => $tok, 'remoteip' => $ip ) ) ) : null;
		$ok  = $res && ! is_wp_error( $res ) && ! empty( json_decode( wp_remote_retrieve_body( $res ), true )['success'] );
		if ( ! $ok ) {
			wp_send_json_error( array( 'message' => 'Please complete the spam check and try again.' ), 400 );
		}
	}

	$g = function ( $k ) {
		return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
	};
	$d = array(
		'full_name'       => $g( 'full_name' ),
		'mobile'          => preg_replace( '/\D/', '', $g( 'mobile' ) ),
		'email'           => sanitize_email( $g( 'email' ) ),
		'dob'             => $g( 'dob' ),
		'gender'          => $g( 'gender' ),
		'city'            => $g( 'city' ),
		'state'           => $g( 'state' ),
		'pincode'         => $g( 'pincode' ),
		'existing_policy' => 'Yes' === $g( 'existing_policy' ) ? 'Yes' : 'No',
		'policy_number'   => $g( 'policy_number' ),
		'coverage'        => $g( 'coverage' ),
		'budget'          => $g( 'budget' ),
		'contact_method'  => $g( 'contact_method' ),
		'contact_time'    => $g( 'contact_time' ),
		'message'         => isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '',
	);
	$type_slug  = sanitize_title( $g( 'insurance_type' ) );
	$product_id = absint( $g( 'product_id' ) );

	$e = array();
	if ( strlen( $d['full_name'] ) < 2 ) {
		$e['full_name'] = 'Please enter your full name.';
	}
	$m = $d['mobile'];
	if ( 12 === strlen( $m ) && 0 === strpos( $m, '91' ) ) {
		$m = substr( $m, 2 );
	}
	if ( 11 === strlen( $m ) && 0 === strpos( $m, '0' ) ) {
		$m = substr( $m, 1 );
	}
	if ( ! preg_match( '/^[6-9]\d{9}$/', $m ) ) {
		$e['mobile'] = 'Enter a valid 10-digit Indian mobile number.';
	}
	$d['mobile'] = $m;
	if ( ! is_email( $d['email'] ) ) {
		$e['email'] = 'Enter a valid email address.';
	}
	if ( '' !== $d['dob'] && ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d['dob'] ) || strtotime( $d['dob'] ) >= time() ) ) {
		$e['dob'] = 'Date of birth must be in the past.';
	}
	$d['dob'] = '' === $d['dob'] ? null : $d['dob'];
	if ( ! in_array( $d['gender'], array( '', 'Male', 'Female', 'Other', 'Prefer not to say' ), true ) ) {
		$d['gender'] = '';
	}
	if ( strlen( $d['city'] ) < 2 ) {
		$e['city'] = 'Please enter your city.';
	}
	if ( ! in_array( $d['state'], ins_states(), true ) ) {
		$e['state'] = 'Please select your state.';
	}
	if ( ! preg_match( '/^[1-9]\d{5}$/', $d['pincode'] ) ) {
		$e['pincode'] = 'Enter a valid 6-digit pincode.';
	}
	if ( ! in_array( $d['contact_method'], array( 'Phone call', 'WhatsApp', 'Email' ), true ) ) {
		$e['contact_method'] = 'Please choose how we should contact you.';
	}
	if ( empty( $_POST['consent'] ) ) {
		$e['consent'] = 'Please tick the consent box so we can contact you.';
	}

	// Product + insurance type.
	$d['product_id']   = 0;
	$d['product_name'] = '';
	if ( $product_id && 'insurance_product' === get_post_type( $product_id ) && 'publish' === get_post_status( $product_id ) ) {
		$d['product_id']   = $product_id;
		$d['product_name'] = get_the_title( $product_id );
		if ( ! $type_slug ) {
			$t = wp_get_post_terms( $product_id, 'insurance_category' );
			$type_slug = ( $t && ! is_wp_error( $t ) ) ? $t[0]->slug : '';
		}
	}
	$term = $type_slug ? get_term_by( 'slug', $type_slug, 'insurance_category' ) : false;
	if ( ! $term ) {
		$e['insurance_type'] = 'Please choose an insurance type.';
	}
	$d['insurance_type'] = $term ? $term->name : '';

	if ( $e ) {
		wp_send_json_error( array( 'errors' => $e, 'message' => 'Please fix the highlighted fields.' ), 422 );
	}

	$d['consent']    = 1;
	$d['source_url'] = substr( esc_url_raw( (string) wp_get_referer(), array( 'http', 'https' ) ), 0, 250 );
	$d['ip_hash']    = hash( 'sha256', $ip . wp_salt() );

	$lead = ins_insert_lead( $d );
	if ( ! $lead ) {
		wp_send_json_error( array( 'message' => 'Sorry, something went wrong while saving your enquiry. Please call us instead.' ), 500 );
	}
	set_transient( $rkey, $hits + 1, HOUR_IN_SECONDS );
	ins_send_emails( $lead );

	$what = $lead['product_name'] ? $lead['product_name'] : $lead['insurance_type'];
	$msg  = sprintf( 'Hello, I am %s. I submitted an enquiry for %s. My enquiry ID is %s.', $lead['full_name'], $what, $lead['lead_code'] );
	$wa   = ins_wa_number() ? 'https://wa.me/' . ins_wa_number() . '?text=' . rawurlencode( $msg ) : '';
	wp_send_json_success( array( 'lead_code' => $lead['lead_code'], 'whatsapp' => $wa ) );
}

/* ---------- Email ---------- */
function ins_tpl( $tpl, $vars, $html = false ) {
	$r = array();
	foreach ( $vars as $k => $v ) {
		$r[ '{' . $k . '}' ] = $html ? esc_html( $v ) : $v;
	}
	return strtr( (string) $tpl, $r );
}

function ins_send_emails( $lead ) {
	$vars = array(
		'lead_id'        => $lead['lead_code'],
		'name'           => $lead['full_name'],
		'mobile'         => $lead['mobile'],
		'email'          => $lead['email'],
		'city'           => $lead['city'],
		'state'          => $lead['state'],
		'insurance_type' => $lead['insurance_type'],
		'product'        => $lead['product_name'] ? $lead['product_name'] : $lead['insurance_type'],
		'coverage'       => $lead['coverage'] ? $lead['coverage'] : 'Not specified',
		'budget'         => $lead['budget'] ? $lead['budget'] : 'Not specified',
		'contact_method' => $lead['contact_method'],
		'contact_time'   => $lead['contact_time'] ? $lead['contact_time'] : 'Anytime',
		'message'        => $lead['message'] ? $lead['message'] : '-',
		'company'        => ins_opt( 'company_name' ),
		'phone'          => ins_opt( 'phone' ),
		'admin_url'      => admin_url( 'admin.php?page=ins-leads&lead=' . (int) $lead['id'] ),
	);
	$wrap = function ( $body ) {
		return '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;color:#0f1b2d;max-width:600px;margin:auto;padding:24px;border:1px solid #e2e8f2;border-radius:12px">' . wpautop( $body ) . '</div>';
	};
	$headers = array( 'Content-Type: text/html; charset=UTF-8' );
	$to      = ins_opt( 'notification_email', get_option( 'admin_email' ) );
	wp_mail( $to, ins_tpl( ins_opt( 'admin_subject' ), $vars ), $wrap( ins_tpl( ins_opt( 'admin_body' ), $vars, true ) ), array_merge( $headers, array( 'Reply-To: ' . $lead['full_name'] . ' <' . $lead['email'] . '>' ) ) );
	wp_mail( $lead['email'], ins_tpl( ins_opt( 'customer_subject' ), $vars ), $wrap( ins_tpl( ins_opt( 'customer_body' ), $vars, true ) ), $headers );
}
