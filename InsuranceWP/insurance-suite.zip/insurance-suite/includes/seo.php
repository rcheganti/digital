<?php
defined( 'ABSPATH' ) || exit;

function ins_json_ld( array $data ) {
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

add_action( 'wp_head', function () {
	$seo_plugin = defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' );

	if ( ! $seo_plugin ) {
		$desc = '';
		if ( is_singular() ) {
			$p    = get_queried_object();
			$desc = has_excerpt( $p ) ? get_the_excerpt( $p ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $p->post_content ) ), 30, '' );
		} elseif ( is_tax() || is_category() ) {
			$desc = wp_strip_all_tags( term_description() );
		} elseif ( is_post_type_archive( 'insurance_product' ) ) {
			$desc = 'Explore health, life, term, motor, travel, home and business insurance plans and get a free quote.';
		}
		if ( ! $desc ) {
			$desc = is_front_page() ? ins_opt( 'hero_text' ) : ins_opt( 'tagline' );
		}
		$desc  = wp_strip_all_tags( $desc );
		$image = '';
		if ( is_singular() && has_post_thumbnail() ) {
			$image = get_the_post_thumbnail_url( null, 'large' );
		} elseif ( ins_opt( 'logo' ) ) {
			$image = wp_get_attachment_image_url( (int) ins_opt( 'logo' ), 'large' );
		}
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:type" content="' . ( is_singular( 'insurance_product' ) ? 'article' : 'website' ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( ins_opt( 'company_name' ) ) . '">' . "\n";
		echo '<meta property="og:url" content="' . esc_url( is_singular() ? get_permalink() : trailingslashit( home_url( $GLOBALS['wp']->request ) ) ) . '">' . "\n";
		if ( $image ) {
			echo '<meta property="og:image" content="' . esc_url( $image ) . '">' . "\n";
		}
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	}

	if ( ins_opt( 'favicon' ) && ! has_site_icon() ) {
		$ico = wp_get_attachment_image_url( (int) ins_opt( 'favicon' ), 'full' );
		if ( $ico ) {
			echo '<link rel="icon" href="' . esc_url( $ico ) . '">' . "\n";
		}
	}

	if ( is_front_page() || is_page( 'contact' ) || is_page( 'about' ) ) {
		$same = array_values( array_filter( array_map( 'ins_opt', array( 'facebook', 'instagram', 'x_twitter', 'linkedin', 'youtube' ) ) ) );
		$org  = array(
			'@context'  => 'https://schema.org',
			'@type'     => 'InsuranceAgency',
			'name'      => ins_opt( 'company_name' ),
			'url'       => home_url( '/' ),
			'telephone' => ins_opt( 'phone' ),
			'email'     => ins_opt( 'email' ),
			'address'   => array( '@type' => 'PostalAddress', 'streetAddress' => implode( ', ', ins_lines( ins_opt( 'address' ) ) ), 'addressCountry' => 'IN' ),
		);
		if ( ins_opt( 'logo' ) ) {
			$org['logo'] = wp_get_attachment_image_url( (int) ins_opt( 'logo' ), 'full' );
		}
		if ( $same ) {
			$org['sameAs'] = $same;
		}
		ins_json_ld( $org );
	}
}, 5 );
