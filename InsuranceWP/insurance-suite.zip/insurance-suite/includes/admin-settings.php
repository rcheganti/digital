<?php
defined( 'ABSPATH' ) || exit;

function ins_settings_schema() {
	$t = 'text';
	return array(
		'General'                    => array(
			'company_name' => array( 'Company name', $t ),
			'tagline'      => array( 'Tagline', $t ),
			'logo'         => array( 'Logo', 'media', 'Shown in header and footer. Leave empty to use the text logo.' ),
			'favicon'      => array( 'Favicon', 'media', 'Square image, at least 64x64. (Or set a Site Icon in Customizer.)' ),
			'cta_text'     => array( 'Primary CTA text', $t, 'Used on the main call-to-action buttons.' ),
		),
		'Contact details'            => array(
			'phone'    => array( 'Phone', $t ),
			'whatsapp' => array( 'WhatsApp number', $t, 'Digits with country code and no plus sign, e.g. 919876543210.' ),
			'email'    => array( 'Public email', 'email' ),
			'address'  => array( 'Address', 'textarea' ),
			'hours'    => array( 'Business hours', 'textarea', 'One line per row.' ),
		),
		'Social media'               => array(
			'facebook'  => array( 'Facebook URL', 'url' ),
			'instagram' => array( 'Instagram URL', 'url' ),
			'x_twitter' => array( 'X (Twitter) URL', 'url' ),
			'linkedin'  => array( 'LinkedIn URL', 'url' ),
			'youtube'   => array( 'YouTube URL', 'url' ),
		),
		'Homepage hero'              => array(
			'hero_title' => array( 'Headline', $t ),
			'hero_text'  => array( 'Supporting text', 'textarea' ),
		),
		'Trust statistics'           => array(
			'stat1_value' => array( 'Stat 1 value', $t, 'Examples: 10K+, 98%, 15+. Numbers animate on the page.' ),
			'stat1_label' => array( 'Stat 1 label', $t ),
			'stat2_value' => array( 'Stat 2 value', $t ),
			'stat2_label' => array( 'Stat 2 label', $t ),
			'stat3_value' => array( 'Stat 3 value', $t ),
			'stat3_label' => array( 'Stat 3 label', $t ),
			'stat4_value' => array( 'Stat 4 value', $t ),
			'stat4_label' => array( 'Stat 4 label', $t ),
		),
		'About page'                 => array(
			'about_intro' => array( 'Company introduction', 'textarea' ),
			'mission'     => array( 'Mission', 'textarea' ),
			'vision'      => array( 'Vision', 'textarea' ),
		),
		'Footer'                     => array(
			'footer_text' => array( 'Short company description', 'textarea' ),
		),
		'Notifications and emails'   => array(
			'notification_email' => array( 'Notification email (admin)', 'email', 'New enquiries are emailed here.' ),
			'admin_subject'      => array( 'Admin email subject', $t, 'Placeholders: {lead_id} {name} {mobile} {email} {city} {state} {insurance_type} {product} {coverage} {budget} {contact_method} {contact_time} {message} {company} {phone} {admin_url}' ),
			'admin_body'         => array( 'Admin email body', 'textarea' ),
			'customer_subject'   => array( 'Customer email subject', $t ),
			'customer_body'      => array( 'Customer email body', 'textarea' ),
		),
		'Spam protection (optional)' => array(
			'turnstile_site'   => array( 'Cloudflare Turnstile site key', $t, 'Free CAPTCHA alternative. Leave empty to use only the built-in honeypot, timing check and rate limit.' ),
			'turnstile_secret' => array( 'Cloudflare Turnstile secret key', $t ),
		),
	);
}

add_action( 'admin_init', function () {
	register_setting( 'ins_settings_group', 'ins_settings', array( 'sanitize_callback' => 'ins_sanitize_settings' ) );
} );

function ins_sanitize_settings( $in ) {
	$in  = (array) $in;
	$out = array();
	foreach ( ins_settings_schema() as $fields ) {
		foreach ( $fields as $k => $f ) {
			$v = isset( $in[ $k ] ) ? $in[ $k ] : '';
			switch ( $f[1] ) {
				case 'url':
					$out[ $k ] = esc_url_raw( $v );
					break;
				case 'email':
					$out[ $k ] = sanitize_email( $v );
					break;
				case 'textarea':
					$out[ $k ] = sanitize_textarea_field( $v );
					break;
				case 'media':
					$out[ $k ] = absint( $v );
					break;
				default:
					$out[ $k ] = sanitize_text_field( $v );
			}
		}
	}
	$out['whatsapp'] = preg_replace( '/\D/', '', (string) $out['whatsapp'] );
	if ( ! is_email( $out['notification_email'] ) ) {
		$out['notification_email'] = get_option( 'admin_email' );
	}
	return $out;
}

function ins_page_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	echo '<div class="wrap ins-wrap"><h1>Insurance Settings</h1>';
	settings_errors();
	echo '<form method="post" action="options.php">';
	settings_fields( 'ins_settings_group' );
	$raw = (array) get_option( 'ins_settings', array() );
	$all = wp_parse_args( $raw, ins_defaults() );
	foreach ( ins_settings_schema() as $title => $fields ) {
		echo '<div class="ins-panel"><h2>' . esc_html( $title ) . '</h2><table class="form-table" role="presentation">';
		foreach ( $fields as $k => $f ) {
			$val  = isset( $all[ $k ] ) ? $all[ $k ] : '';
			$name = 'ins_settings[' . $k . ']';
			echo '<tr><th scope="row"><label for="ins_' . esc_attr( $k ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
			if ( 'textarea' === $f[1] ) {
				echo '<textarea class="large-text" rows="4" id="ins_' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '">' . esc_textarea( $val ) . '</textarea>';
			} elseif ( 'media' === $f[1] ) {
				$url = $val ? wp_get_attachment_image_url( (int) $val, 'medium' ) : '';
				echo '<div class="ins-media"><img src="' . esc_url( $url ) . '" alt="" ' . ( $url ? '' : 'hidden' ) . '><input type="hidden" id="ins_' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '" value="' . (int) $val . '"><button type="button" class="button ins-media-pick">Choose image</button> <button type="button" class="button-link-delete ins-media-clear">Remove</button></div>';
			} else {
				$type = in_array( $f[1], array( 'url', 'email' ), true ) ? $f[1] : 'text';
				echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="ins_' . esc_attr( $k ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '">';
			}
			if ( ! empty( $f[2] ) ) {
				echo '<p class="description">' . esc_html( $f[2] ) . '</p>';
			}
			echo '</td></tr>';
		}
		echo '</table></div>';
	}
	submit_button( 'Save settings' );
	echo '</form></div>';
}
