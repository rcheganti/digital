<?php
defined( 'ABSPATH' ) || exit;

function ins_register_types() {
	register_taxonomy( 'insurance_category', 'insurance_product', array(
		'labels'            => array( 'name' => 'Insurance Categories', 'singular_name' => 'Insurance Category', 'add_new_item' => 'Add Insurance Category', 'menu_name' => 'Categories' ),
		'hierarchical'      => true,
		'public'            => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'insurance-category' ),
	) );
	register_post_type( 'insurance_product', array(
		'labels'        => array( 'name' => 'Insurance Products', 'singular_name' => 'Insurance Product', 'add_new_item' => 'Add Insurance Product', 'edit_item' => 'Edit Insurance Product', 'menu_name' => 'Insurance Products' ),
		'public'        => true,
		'has_archive'   => 'insurance',
		'rewrite'       => array( 'slug' => 'insurance' ),
		'menu_icon'     => 'dashicons-shield',
		'menu_position' => 25,
		'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
		'show_in_rest'  => true,
		'taxonomies'    => array( 'insurance_category' ),
	) );
	register_taxonomy( 'faq_category', 'ins_faq', array(
		'labels'            => array( 'name' => 'FAQ Categories', 'singular_name' => 'FAQ Category', 'menu_name' => 'FAQ Categories' ),
		'hierarchical'      => true,
		'public'            => false,
		'show_ui'           => true,
		'show_admin_column' => true,
	) );
	register_post_type( 'ins_faq', array(
		'labels'        => array( 'name' => 'FAQs', 'singular_name' => 'FAQ', 'add_new_item' => 'Add FAQ', 'edit_item' => 'Edit FAQ' ),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-editor-help',
		'menu_position' => 27,
		'supports'      => array( 'title', 'editor', 'page-attributes' ),
		'taxonomies'    => array( 'faq_category' ),
	) );
	register_post_type( 'ins_testimonial', array(
		'labels'        => array( 'name' => 'Testimonials', 'singular_name' => 'Testimonial', 'add_new_item' => 'Add Testimonial', 'edit_item' => 'Edit Testimonial' ),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-format-quote',
		'menu_position' => 28,
		'supports'      => array( 'title', 'editor', 'thumbnail' ),
	) );
	register_post_type( 'ins_team', array(
		'labels'        => array( 'name' => 'Team Members', 'singular_name' => 'Team Member', 'add_new_item' => 'Add Team Member', 'edit_item' => 'Edit Team Member' ),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-businessperson',
		'menu_position' => 29,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
	) );
}
add_action( 'init', 'ins_register_types' );

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'ins_product', 'Product details', 'ins_mb_product', 'insurance_product', 'normal', 'high' );
	add_meta_box( 'ins_testi', 'Testimonial details', 'ins_mb_testi', 'ins_testimonial', 'side' );
	add_meta_box( 'ins_teamb', 'Team member details', 'ins_mb_team', 'ins_team', 'side' );
} );

function ins_product_lists() {
	return array(
		'_ins_benefits'    => array( 'Key benefits', 'One benefit per line.' ),
		'_ins_features'    => array( 'Features', 'One feature per line.' ),
		'_ins_coverage'    => array( 'Coverage (what is covered)', 'One item per line.' ),
		'_ins_eligibility' => array( 'Eligibility', 'One criterion per line.' ),
		'_ins_documents'   => array( 'Required documents', 'One document per line.' ),
	);
}

function ins_mb_product( $post ) {
	wp_nonce_field( 'ins_save_meta', 'ins_meta_nonce' );
	$m = function ( $k ) use ( $post ) {
		return get_post_meta( $post->ID, $k, true );
	};
	echo '<div class="ins-metabox">';
	echo '<p><label><input type="checkbox" name="_ins_featured" value="1" ' . checked( $m( '_ins_featured' ), '1', false ) . '> <strong>Featured product</strong> (shown first on the homepage)</label></p>';
	echo '<p><label for="ins_kb"><strong>Key benefit</strong> (one short line shown on the product card)</label><input type="text" class="widefat" id="ins_kb" name="_ins_key_benefit" value="' . esc_attr( $m( '_ins_key_benefit' ) ) . '"></p>';
	echo '<p><label for="ins_cta"><strong>CTA button text</strong> (default: Get Quote)</label><input type="text" class="widefat" id="ins_cta" name="_ins_cta_text" value="' . esc_attr( $m( '_ins_cta_text' ) ) . '"></p>';
	foreach ( ins_product_lists() as $key => $def ) {
		echo '<p><label for="' . esc_attr( $key ) . '"><strong>' . esc_html( $def[0] ) . '</strong> <span class="description">' . esc_html( $def[1] ) . '</span></label>';
		echo '<textarea class="widefat" rows="4" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $m( $key ) ) . '</textarea></p>';
	}
	$faqs = $m( '_ins_faqs' );
	$faqs = is_array( $faqs ) ? $faqs : array();
	echo '<h4>Product FAQs</h4><div class="ins-repeater" id="ins-faq-rep">';
	foreach ( $faqs as $f ) {
		ins_faq_row( $f['q'], $f['a'] );
	}
	echo '</div><p><button type="button" class="button" id="ins-faq-add">Add FAQ</button></p>';
	echo '<template id="ins-faq-tpl">';
	ins_faq_row( '', '' );
	echo '</template></div>';
}
function ins_faq_row( $q, $a ) {
	echo '<div class="ins-rep-row"><input type="text" class="widefat" name="_ins_faq_q[]" placeholder="Question" value="' . esc_attr( $q ) . '"><textarea class="widefat" rows="2" name="_ins_faq_a[]" placeholder="Answer">' . esc_textarea( $a ) . '</textarea><button type="button" class="button-link-delete ins-rep-del">Remove</button></div>';
}

function ins_mb_testi( $post ) {
	wp_nonce_field( 'ins_save_meta', 'ins_meta_nonce' );
	$r = (int) get_post_meta( $post->ID, '_ins_rating', true );
	$r = $r ? $r : 5;
	echo '<p>The <em>title</em> is the customer name. Use "Featured image" for the customer photo.</p>';
	echo '<p><label for="ins_rating"><strong>Rating</strong></label><select name="_ins_rating" id="ins_rating" class="widefat">';
	for ( $i = 5; $i >= 1; $i-- ) {
		echo '<option value="' . $i . '" ' . selected( $r, $i, false ) . '>' . $i . ' star' . ( $i > 1 ? 's' : '' ) . '</option>';
	}
	echo '</select></p>';
	echo '<p><label for="ins_role"><strong>City / designation</strong></label><input type="text" class="widefat" id="ins_role" name="_ins_role" value="' . esc_attr( get_post_meta( $post->ID, '_ins_role', true ) ) . '"></p>';
}
function ins_mb_team( $post ) {
	wp_nonce_field( 'ins_save_meta', 'ins_meta_nonce' );
	echo '<p><label for="ins_role"><strong>Role / designation</strong></label><input type="text" class="widefat" id="ins_role" name="_ins_role" value="' . esc_attr( get_post_meta( $post->ID, '_ins_role', true ) ) . '"></p>';
}

add_action( 'save_post', function ( $id, $post ) {
	if ( ! isset( $_POST['ins_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ins_meta_nonce'] ) ), 'ins_save_meta' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	$txt = function ( $k ) {
		return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
	};
	$set = function ( $k, $v ) use ( $id ) {
		if ( '' === $v ) {
			delete_post_meta( $id, $k );
		} else {
			update_post_meta( $id, $k, $v );
		}
	};
	if ( 'insurance_product' === $post->post_type ) {
		$set( '_ins_featured', isset( $_POST['_ins_featured'] ) ? '1' : '' );
		$set( '_ins_key_benefit', $txt( '_ins_key_benefit' ) );
		$set( '_ins_cta_text', $txt( '_ins_cta_text' ) );
		foreach ( array_keys( ins_product_lists() ) as $k ) {
			$set( $k, isset( $_POST[ $k ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) : '' );
		}
		$qs   = isset( $_POST['_ins_faq_q'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['_ins_faq_q'] ) ) : array();
		$as   = isset( $_POST['_ins_faq_a'] ) ? array_map( 'sanitize_textarea_field', wp_unslash( (array) $_POST['_ins_faq_a'] ) ) : array();
		$faqs = array();
		foreach ( $qs as $i => $q ) {
			if ( '' !== trim( $q ) && ! empty( $as[ $i ] ) ) {
				$faqs[] = array( 'q' => $q, 'a' => $as[ $i ] );
			}
		}
		if ( $faqs ) {
			update_post_meta( $id, '_ins_faqs', $faqs );
		} else {
			delete_post_meta( $id, '_ins_faqs' );
		}
	} elseif ( 'ins_testimonial' === $post->post_type ) {
		$r = isset( $_POST['_ins_rating'] ) ? min( 5, max( 1, absint( $_POST['_ins_rating'] ) ) ) : 5;
		update_post_meta( $id, '_ins_rating', $r );
		$set( '_ins_role', $txt( '_ins_role' ) );
	} elseif ( 'ins_team' === $post->post_type ) {
		$set( '_ins_role', $txt( '_ins_role' ) );
	}
}, 10, 2 );

// Admin list: "Featured" column.
add_filter( 'manage_insurance_product_posts_columns', function ( $c ) {
	$c['ins_featured'] = 'Featured';
	return $c;
} );
add_action( 'manage_insurance_product_posts_custom_column', function ( $col, $id ) {
	if ( 'ins_featured' === $col ) {
		echo get_post_meta( $id, '_ins_featured', true ) ? '<span class="dashicons dashicons-star-filled" style="color:#dba617" title="Featured"></span>' : '&ndash;';
	}
}, 10, 2 );

// Duplicate product (row action).
add_filter( 'post_row_actions', function ( $actions, $post ) {
	if ( 'insurance_product' === $post->post_type && current_user_can( 'edit_posts' ) ) {
		$url                  = wp_nonce_url( admin_url( 'admin.php?action=ins_duplicate&post=' . $post->ID ), 'ins_dup_' . $post->ID );
		$actions['ins_dup'] = '<a href="' . esc_url( $url ) . '">Duplicate</a>';
	}
	return $actions;
}, 10, 2 );
add_action( 'admin_action_ins_duplicate', function () {
	$id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
	check_admin_referer( 'ins_dup_' . $id );
	$src = get_post( $id );
	if ( ! $src || 'insurance_product' !== $src->post_type || ! current_user_can( 'edit_post', $id ) ) {
		wp_die( 'Not allowed.' );
	}
	$new = wp_insert_post( array(
		'post_type'    => 'insurance_product',
		'post_status'  => 'draft',
		'post_title'   => $src->post_title . ' (Copy)',
		'post_content' => $src->post_content,
		'post_excerpt' => $src->post_excerpt,
	) );
	if ( $new && ! is_wp_error( $new ) ) {
		foreach ( get_post_meta( $id ) as $k => $vals ) {
			if ( 0 === strpos( $k, '_ins_' ) || '_thumbnail_id' === $k ) {
				update_post_meta( $new, $k, maybe_unserialize( $vals[0] ) );
			}
		}
		wp_set_object_terms( $new, wp_get_object_terms( $id, 'insurance_category', array( 'fields' => 'ids' ) ), 'insurance_category' );
		wp_safe_redirect( admin_url( 'post.php?action=edit&post=' . $new ) );
		exit;
	}
	wp_die( 'Could not duplicate.' );
} );

// 12 products per archive page.
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && ( $q->is_post_type_archive( 'insurance_product' ) || $q->is_tax( 'insurance_category' ) ) ) {
		$q->set( 'posts_per_page', 12 );
	}
} );
