<?php
defined( 'ABSPATH' ) || exit;

function ins_bars( $rows ) {
	if ( ! $rows ) {
		return '<p class="ins-empty">No data yet.</p>';
	}
	$max = max( array_map( function ( $r ) {
		return (int) $r->c;
	}, $rows ) );
	$out = '<ul class="ins-bars">';
	foreach ( $rows as $r ) {
		$w    = $max ? round( ( (int) $r->c / $max ) * 100 ) : 0;
		$out .= '<li><span class="b-label">' . esc_html( $r->label ) . '</span><span class="b-track"><span class="b-fill" style="width:' . (int) $w . '%"></span></span><span class="b-val">' . (int) $r->c . '</span></li>';
	}
	return $out . '</ul>';
}

function ins_page_dashboard() {
	if ( ! current_user_can( 'manage_insurance_leads' ) ) {
		wp_die( 'You do not have permission to view this page.' );
	}
	global $wpdb;
	$t      = ins_table();
	$total  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t" ); // phpcs:ignore
	$status = $wpdb->get_results( "SELECT status, COUNT(*) AS c FROM $t GROUP BY status", OBJECT_K ); // phpcs:ignore
	$cnt    = function ( $s ) use ( $status ) {
		return isset( $status[ $s ] ) ? (int) $status[ $s ]->c : 0;
	};
	$conv   = $cnt( 'Converted' );
	$rate   = $total ? round( $conv / $total * 100, 1 ) : 0;
	$types  = $wpdb->get_results( "SELECT insurance_type AS label, COUNT(*) AS c FROM $t WHERE insurance_type <> '' GROUP BY insurance_type ORDER BY c DESC LIMIT 8" ); // phpcs:ignore
	$prods  = $wpdb->get_results( "SELECT product_name AS label, COUNT(*) AS c FROM $t WHERE product_name <> '' GROUP BY product_name ORDER BY c DESC LIMIT 8" ); // phpcs:ignore
	$since  = gmdate( 'Y-m-01 00:00:00', strtotime( '-5 months', current_time( 'timestamp' ) ) );
	$mrows  = $wpdb->get_results( $wpdb->prepare( "SELECT DATE_FORMAT(created_at,'%%Y-%%m') AS m, COUNT(*) AS c FROM $t WHERE created_at >= %s GROUP BY m", $since ), OBJECT_K ); // phpcs:ignore
	$months = array();
	for ( $i = 5; $i >= 0; $i-- ) {
		$ts       = strtotime( "-$i months", current_time( 'timestamp' ) );
		$key      = gmdate( 'Y-m', $ts );
		$months[] = array( gmdate( 'M', $ts ), isset( $mrows[ $key ] ) ? (int) $mrows[ $key ]->c : 0 );
	}
	$mmax   = max( 1, max( array_column( $months, 1 ) ) );
	$recent = $wpdb->get_results( "SELECT id, lead_code, full_name, mobile, insurance_type, product_name, status, created_at FROM $t ORDER BY id DESC LIMIT 8", ARRAY_A ); // phpcs:ignore
	$kpis   = array(
		array( 'Total leads', $total ),
		array( 'New leads', $cnt( 'New' ) ),
		array( 'Follow-ups', $cnt( 'Follow-up' ) ),
		array( 'Converted', $conv ),
		array( 'Conversion rate', $rate . '%' ),
	);
	echo '<div class="wrap ins-wrap"><h1>Insurance Dashboard</h1><div class="ins-kpis">';
	foreach ( $kpis as $k ) {
		echo '<div class="ins-kpi"><span>' . esc_html( $k[0] ) . '</span><strong>' . esc_html( $k[1] ) . '</strong></div>';
	}
	echo '</div><div class="ins-charts">';
	echo '<div class="ins-panel"><h2>Leads by insurance type</h2>' . ins_bars( $types ) . '</div>'; // phpcs:ignore
	echo '<div class="ins-panel"><h2>Leads by product</h2>' . ins_bars( $prods ) . '</div>'; // phpcs:ignore
	echo '<div class="ins-panel"><h2>Leads by month</h2><div class="ins-cols-chart" role="img" aria-label="Leads per month for the last six months">';
	foreach ( $months as $m ) {
		echo '<div class="c-col"><span class="c-val">' . (int) $m[1] . '</span><span class="c-bar" style="height:' . (int) round( $m[1] / $mmax * 100 ) . '%"></span><span class="c-lbl">' . esc_html( $m[0] ) . '</span></div>';
	}
	echo '</div></div>';
	echo '<div class="ins-panel"><h2>Lead status distribution</h2>';
	if ( $total ) {
		echo '<div class="ins-stack" role="img" aria-label="Status distribution">';
		foreach ( ins_statuses() as $s ) {
			if ( $cnt( $s ) ) {
				echo '<span class="ins-badge--' . esc_attr( sanitize_title( $s ) ) . ' seg" style="width:' . esc_attr( round( $cnt( $s ) / $total * 100, 2 ) ) . '%" title="' . esc_attr( $s . ': ' . $cnt( $s ) ) . '"></span>';
			}
		}
		echo '</div><ul class="ins-legend">';
		foreach ( ins_statuses() as $s ) {
			echo '<li>' . ins_status_badge( $s ) . ' <strong>' . (int) $cnt( $s ) . '</strong></li>'; // phpcs:ignore
		}
		echo '</ul>';
	} else {
		echo '<p class="ins-empty">No data yet.</p>';
	}
	echo '</div></div>';
	echo '<div class="ins-panel"><h2>Recent leads</h2>';
	if ( ! $recent ) {
		echo '<p class="ins-empty">No enquiries yet. Submit the form on your website to see the first lead here.</p>';
	} else {
		echo '<div class="ins-scroll"><table class="wp-list-table widefat striped"><thead><tr><th>Lead ID</th><th>Customer</th><th>Mobile</th><th>Insurance</th><th>Status</th><th>Received</th></tr></thead><tbody>';
		foreach ( $recent as $r ) {
			echo '<tr><td><a href="' . esc_url( admin_url( 'admin.php?page=ins-leads&lead=' . (int) $r['id'] ) ) . '"><strong>' . esc_html( $r['lead_code'] ) . '</strong></a></td><td>' . esc_html( $r['full_name'] ) . '</td><td>' . esc_html( $r['mobile'] ) . '</td><td>' . esc_html( trim( $r['insurance_type'] . ' / ' . $r['product_name'], ' /' ) ) . '</td><td>' . ins_status_badge( $r['status'] ) . '</td><td>' . esc_html( mysql2date( 'd M Y, h:i A', $r['created_at'] ) ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div><p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=ins-leads' ) ) . '">View all leads</a></p>';
	}
	echo '</div></div>';
}
