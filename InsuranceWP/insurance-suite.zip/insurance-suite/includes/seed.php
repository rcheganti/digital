<?php
defined( 'ABSPATH' ) || exit;

/** Demo content so the site looks complete right after activation. Edit or delete it from the admin. */
function ins_seed() {
	$cats = array( 'Health Insurance', 'Life Insurance', 'Term Insurance', 'Motor Insurance', 'Car Insurance', 'Two-Wheeler Insurance', 'Travel Insurance', 'Home Insurance', 'Business Insurance', 'Other Insurance' );
	foreach ( $cats as $c ) {
		if ( ! term_exists( $c, 'insurance_category' ) ) {
			wp_insert_term( $c, 'insurance_category' );
		}
	}
	$demo = array(
		array( 'Family Health Shield', 'health-insurance', 'Comprehensive family floater with cashless treatment at a wide hospital network.', 'Cashless cover at 10,000+ hospitals', 1,
			array( 'Cashless hospitalisation', 'No-claim bonus every year', 'Free yearly health check-up' ), array( 'Sum insured from ₹5 lakh to ₹1 crore', 'Covers self, spouse, children and parents', 'Day-care procedures included' ), array( 'In-patient hospitalisation', 'Pre and post hospitalisation expenses', 'Ambulance charges' ), array( 'Age 18 to 65 for the proposer', 'Children from 3 months', 'Medical screening may apply above 50' ), array( 'Identity proof', 'Address proof', 'Recent photograph', 'Age proof' ) ),
		array( 'Pure Term Protect', 'term-insurance', 'High life cover at a low premium so your family stays financially secure.', 'Up to ₹2 crore cover from ₹500 a month', 1,
			array( 'High cover at low premium', 'Tax benefits under Section 80C', 'Optional critical illness rider' ), array( 'Cover till age 85', 'Online and offline premium payment', 'Waiver of premium on disability' ), array( 'Death benefit to nominee', 'Accidental death rider (optional)', 'Terminal illness benefit' ), array( 'Age 18 to 60', 'Indian resident or NRI', 'Regular income source' ), array( 'Identity proof', 'Income proof', 'Address proof', 'Medical reports if requested' ) ),
		array( 'Life Savings Plan', 'life-insurance', 'Guaranteed returns with life cover to help you plan for future goals.', 'Guaranteed returns plus life cover', 0,
			array( 'Guaranteed maturity benefit', 'Life cover throughout the term', 'Loan against policy' ), array( 'Flexible premium terms', 'Bonus additions', 'Tax efficient maturity' ), array( 'Death benefit', 'Maturity benefit', 'Surrender value' ), array( 'Age 18 to 55', 'Minimum annual premium applies' ), array( 'Identity proof', 'Address proof', 'Income proof' ) ),
		array( 'Comprehensive Car Cover', 'car-insurance', 'Own damage and third-party protection with fast, hassle-free claims.', 'Zero depreciation add-on available', 1,
			array( 'Zero depreciation add-on', '24x7 roadside assistance', 'Cashless garage network' ), array( 'Instant policy issuance', 'No-claim bonus up to 50%', 'Engine protection add-on' ), array( 'Accidental damage', 'Theft and fire', 'Natural calamities', 'Third-party liability' ), array( 'Valid registration certificate', 'Valid driving licence' ), array( 'RC copy', 'Previous policy (for renewal)', 'Driving licence', 'Identity proof' ) ),
		array( 'Two-Wheeler Secure', 'two-wheeler-insurance', 'Affordable cover for your bike or scooter with personal accident benefit.', 'Policy in minutes from ₹700 a year', 0,
			array( 'Instant online policy', 'Personal accident cover', 'Easy renewal' ), array( 'Own damage and third-party', 'Add-ons for helmet and accessories', 'Cashless repair network' ), array( 'Accidental damage', 'Theft', 'Third-party injury or damage' ), array( 'Valid RC and driving licence' ), array( 'RC copy', 'Driving licence', 'Previous policy' ) ),
		array( 'Globe Trotter Travel', 'travel-insurance', 'Medical, baggage and trip cover for domestic and international journeys.', 'Medical cover up to USD 500,000', 0,
			array( 'Overseas medical cover', 'Trip delay and cancellation', 'Lost passport assistance' ), array( 'Covers 150+ countries', 'Instant e-policy', '24x7 global helpline' ), array( 'Emergency medical expenses', 'Checked-in baggage loss', 'Flight delay', 'Trip cancellation' ), array( 'Age 6 months to 70 years', 'Valid passport and visa' ), array( 'Passport copy', 'Visa copy', 'Travel tickets' ) ),
		array( 'Home Shield', 'home-insurance', 'Protect your home structure and belongings from fire, theft and natural calamities.', 'Covers structure and contents', 0,
			array( 'Structure and contents cover', 'Alternate accommodation', 'Low premium' ), array( 'Long term options', 'Add-on for jewellery and valuables', 'Quick claims' ), array( 'Fire and allied perils', 'Burglary and theft', 'Flood and earthquake' ), array( 'Home owner or tenant', 'Property in India' ), array( 'Ownership or rent proof', 'Identity proof', 'Property valuation if requested' ) ),
		array( 'Business Secure', 'business-insurance', 'Tailored cover for shops, offices and small businesses against everyday risks.', 'One policy for property, stock and liability', 0,
			array( 'Property and stock cover', 'Public liability', 'Employee protection options' ), array( 'Customisable packages', 'Business interruption add-on', 'Dedicated claims desk' ), array( 'Fire and burglary', 'Machinery breakdown', 'Liability to third parties' ), array( 'Registered business or shop', 'Premises in India' ), array( 'Business registration', 'Address proof', 'Stock or asset list' ) ),
	);
	foreach ( $demo as $d ) {
		$id = wp_insert_post( array( 'post_type' => 'insurance_product', 'post_status' => 'publish', 'post_title' => $d[0], 'post_excerpt' => $d[2], 'post_content' => $d[2] . ' Talk to our advisors for a free comparison and a quote tailored to you.' ) );
		if ( ! $id || is_wp_error( $id ) ) {
			continue;
		}
		wp_set_object_terms( $id, $d[1], 'insurance_category' );
		update_post_meta( $id, '_ins_key_benefit', $d[3] );
		if ( $d[4] ) {
			update_post_meta( $id, '_ins_featured', '1' );
		}
		foreach ( array( 5 => 'benefits', 6 => 'features', 7 => 'coverage', 8 => 'eligibility', 9 => 'documents' ) as $i => $k ) {
			update_post_meta( $id, '_ins_' . $k, implode( "\n", $d[ $i ] ) );
		}
		update_post_meta( $id, '_ins_faqs', array(
			array( 'q' => 'How quickly can I get this policy?', 'a' => 'Most policies are issued within one working day after documents are verified. Some plans can be issued instantly online.' ),
			array( 'q' => 'Can I get help with the claim process?', 'a' => 'Yes. Our team guides you through documentation and follows up with the insurer until the claim is settled.' ),
		) );
	}

	$faq_cat = wp_insert_term( 'General', 'faq_category' );
	$faqs    = array(
		array( 'How do I choose the right insurance plan?', 'Share your needs with our advisor. We compare plans from multiple insurers and explain coverage, exclusions and costs in plain language.' ),
		array( 'Is there any fee for your advice?', 'No. Our guidance and quote comparison are free. You pay only the insurer premium for the policy you choose.' ),
		array( 'How long does it take to hear back after I submit an enquiry?', 'We usually call or message within a few working hours, in the time slot you choose on the form.' ),
		array( 'Can you help me renew or port an existing policy?', 'Yes. Mention your existing policy on the enquiry form and we will review it and suggest the best renewal or porting option.' ),
		array( 'Which documents are required?', 'It depends on the product. Each plan page lists the documents needed. Typically identity proof, address proof and age proof are enough to start.' ),
		array( 'Is my personal information safe?', 'Your details are stored securely and are visible only to authorised advisors. We never sell your data.' ),
	);
	foreach ( $faqs as $i => $f ) {
		$id = wp_insert_post( array( 'post_type' => 'ins_faq', 'post_status' => 'publish', 'post_title' => $f[0], 'post_content' => $f[1], 'menu_order' => $i ) );
		if ( $id && ! is_wp_error( $id ) && ! is_wp_error( $faq_cat ) ) {
			wp_set_object_terms( $id, (int) $faq_cat['term_id'], 'faq_category' );
		}
	}

	$testi = array(
		array( 'Ananya Rao', 'Hyderabad', 'They compared five health plans for my parents and explained every exclusion. Booking took one call and the policy arrived the next day.' ),
		array( 'Rahul Mehta', 'Pune', 'My car claim was settled quickly because the team coordinated with the garage and the insurer. Genuinely helpful.' ),
		array( 'Sneha Iyer', 'Chennai', 'I finally understood term insurance. No pressure, clear numbers and a plan that fits my budget.' ),
	);
	foreach ( $testi as $t ) {
		$id = wp_insert_post( array( 'post_type' => 'ins_testimonial', 'post_status' => 'publish', 'post_title' => $t[0], 'post_content' => $t[2] ) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_ins_rating', 5 );
			update_post_meta( $id, '_ins_role', $t[1] );
		}
	}

	$team = array(
		array( 'Priya Sharma', 'Founder and Principal Advisor', 'Over 15 years guiding families through life and health insurance decisions.' ),
		array( 'Arjun Reddy', 'Head of Claims Support', 'Makes sure every claim is documented right and followed up until it is settled.' ),
		array( 'Meera Nair', 'Business Insurance Specialist', 'Helps small businesses build practical cover for property, stock and liability.' ),
	);
	foreach ( $team as $i => $t ) {
		$id = wp_insert_post( array( 'post_type' => 'ins_team', 'post_status' => 'publish', 'post_title' => $t[0], 'post_content' => $t[2], 'menu_order' => $i ) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_ins_role', $t[1] );
		}
	}
}
