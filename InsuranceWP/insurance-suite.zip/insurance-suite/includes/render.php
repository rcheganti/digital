<?php
defined( 'ABSPATH' ) || exit;

function ins_render_stats() {
	$out = '<div class="stats-grid">';
	for ( $i = 1; $i <= 4; $i++ ) {
		$v = (string) ins_opt( "stat{$i}_value" );
		$l = (string) ins_opt( "stat{$i}_label" );
		if ( '' === $v && '' === $l ) {
			continue;
		}
		if ( preg_match( '/^(\D*?)(\d+(?:\.\d+)?)(.*)$/u', $v, $m ) ) {
			$num = '<strong class="stat-num" data-prefix="' . esc_attr( $m[1] ) . '" data-count="' . esc_attr( $m[2] ) . '" data-suffix="' . esc_attr( $m[3] ) . '">' . esc_html( $v ) . '</strong>';
		} else {
			$num = '<strong class="stat-num">' . esc_html( $v ) . '</strong>';
		}
		$out .= '<div class="stat">' . $num . '<span class="stat-label">' . esc_html( $l ) . '</span></div>';
	}
	return $out . '</div>';
}
add_shortcode( 'ins_stats', 'ins_render_stats' );

function ins_get_products( $a = array() ) {
	$a = wp_parse_args( $a, array( 'limit' => 8, 'category' => '', 'featured_first' => false, 'exclude' => array() ) );
	$q = array(
		'post_type'      => 'insurance_product',
		'post_status'    => 'publish',
		'posts_per_page' => (int) $a['limit'],
		'no_found_rows'  => true,
		'post__not_in'   => (array) $a['exclude'],
		'fields'         => 'ids',
	);
	if ( $a['category'] ) {
		$q['tax_query'] = array( array( 'taxonomy' => 'insurance_category', 'field' => 'slug', 'terms' => $a['category'] ) );
	}
	if ( $a['featured_first'] ) {
		$q['meta_query'] = array(
			'relation' => 'OR',
			'feat'     => array( 'key' => '_ins_featured', 'compare' => 'EXISTS' ),
			array( 'key' => '_ins_featured', 'compare' => 'NOT EXISTS' ),
		);
		$q['orderby']    = array( 'feat' => 'DESC', 'date' => 'DESC' );
	}
	return get_posts( $q );
}

function ins_render_product_card( $id ) {
	$terms = get_the_terms( $id, 'insurance_category' );
	$cat   = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0] : null;
	$kb    = get_post_meta( $id, '_ins_key_benefit', true );
	$cta   = get_post_meta( $id, '_ins_cta_text', true );
	$cta   = $cta ? $cta : 'Get Quote';
	$slug  = $cat ? $cat->slug : '';
	$link  = get_permalink( $id );
	ob_start();
	?>
	<article class="card product-card">
		<a class="pc-media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
			<?php
			if ( has_post_thumbnail( $id ) ) {
				echo get_the_post_thumbnail( $id, 'medium_large', array( 'loading' => 'lazy', 'alt' => '' ) );
			} else {
				echo '<span class="pc-icon">' . ins_icon( ins_category_icon( $slug ), 40 ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			?>
		</a>
		<div class="pc-body">
			<?php if ( $cat ) : ?>
				<a class="pc-cat" href="<?php echo esc_url( get_term_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
			<?php endif; ?>
			<h3 class="pc-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( get_the_title( $id ) ); ?></a></h3>
			<p class="pc-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt( $id ), 22 ) ); ?></p>
			<?php if ( $kb ) : ?>
				<p class="pc-benefit"><?php echo ins_icon( 'check', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $kb ); ?></span></p>
			<?php endif; ?>
			<div class="pc-actions">
				<a class="btn btn-ghost" href="<?php echo esc_url( $link ); ?>">View Details</a>
				<a class="btn btn-primary" href="<?php echo esc_url( ins_quote_url( $id, $slug ) ); ?>" data-open-quote data-product="<?php echo (int) $id; ?>" data-type="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $cta ); ?></a>
			</div>
		</div>
	</article>
	<?php
	return ob_get_clean();
}

function ins_render_products( $a = array() ) {
	$ids = ins_get_products( $a );
	if ( ! $ids ) {
		return '<div class="empty"><p>No insurance plans are available right now. Please check back soon.</p></div>';
	}
	$out = '<div class="cards">';
	foreach ( $ids as $id ) {
		$out .= ins_render_product_card( $id );
	}
	return $out . '</div>';
}
add_shortcode( 'ins_products', function ( $atts ) {
	$atts = shortcode_atts( array( 'limit' => 8, 'category' => '', 'featured' => '' ), $atts );
	return ins_render_products( array( 'limit' => (int) $atts['limit'], 'category' => sanitize_title( $atts['category'] ), 'featured_first' => (bool) $atts['featured'] ) );
} );

/** Accessible accordion. $items = array( array( 'q' => , 'a' => ), ... ). */
function ins_render_accordion( $items, $schema = true ) {
	static $n = 0;
	if ( ! $items ) {
		return '';
	}
	$out = '<div class="acc">';
	$ld  = array();
	foreach ( $items as $it ) {
		$n++;
		$out .= '<div class="acc-item"><h3><button type="button" class="acc-btn" id="acc-b' . $n . '" aria-expanded="false" aria-controls="acc-p' . $n . '"><span>' . esc_html( $it['q'] ) . '</span>' . ins_icon( 'chevron', 20 ) . '</button></h3>';
		$out .= '<div class="acc-panel" id="acc-p' . $n . '" role="region" aria-labelledby="acc-b' . $n . '"><div class="acc-inner">' . wpautop( esc_html( $it['a'] ) ) . '</div></div></div>';
		$ld[] = array( '@type' => 'Question', 'name' => $it['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $it['a'] ) );
	}
	$out .= '</div>';
	if ( $schema ) {
		$out .= '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $ld ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . '</script>';
	}
	return $out;
}

function ins_render_faqs( $a = array() ) {
	$a = wp_parse_args( $a, array( 'category' => '', 'limit' => -1, 'schema' => true ) );
	$q = array( 'post_type' => 'ins_faq', 'post_status' => 'publish', 'posts_per_page' => (int) $a['limit'], 'no_found_rows' => true, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'ASC' ) );
	if ( $a['category'] ) {
		$q['tax_query'] = array( array( 'taxonomy' => 'faq_category', 'field' => 'slug', 'terms' => $a['category'] ) );
	}
	$items = array();
	foreach ( get_posts( $q ) as $p ) {
		$items[] = array( 'q' => get_the_title( $p ), 'a' => wp_strip_all_tags( $p->post_content ) );
	}
	return $items ? ins_render_accordion( $items, $a['schema'] ) : '<div class="empty"><p>No FAQs yet.</p></div>';
}
add_shortcode( 'ins_faqs', function ( $atts ) {
	$atts = shortcode_atts( array( 'category' => '', 'limit' => -1 ), $atts );
	return ins_render_faqs( array( 'category' => sanitize_title( $atts['category'] ), 'limit' => (int) $atts['limit'] ) );
} );

function ins_stars( $n ) {
	$out = '<span class="t-stars" role="img" aria-label="' . (int) $n . ' out of 5 stars">';
	for ( $i = 1; $i <= 5; $i++ ) {
		$out .= '<span class="' . ( $i <= $n ? 'on' : '' ) . '">' . ins_icon( 'star', 18 ) . '</span>';
	}
	return $out . '</span>';
}

function ins_render_testimonials( $limit = 12 ) {
	$posts = get_posts( array( 'post_type' => 'ins_testimonial', 'post_status' => 'publish', 'posts_per_page' => (int) $limit, 'no_found_rows' => true ) );
	if ( ! $posts ) {
		return '';
	}
	$out = '<div class="carousel" data-carousel><ul class="carousel-track" tabindex="0" aria-label="Customer testimonials">';
	foreach ( $posts as $p ) {
		$r    = (int) get_post_meta( $p->ID, '_ins_rating', true );
		$role = get_post_meta( $p->ID, '_ins_role', true );
		$img  = has_post_thumbnail( $p->ID ) ? get_the_post_thumbnail( $p->ID, 'thumbnail', array( 'loading' => 'lazy', 'alt' => '', 'class' => 'avatar' ) ) : '<span class="avatar avatar--init" aria-hidden="true">' . esc_html( mb_substr( $p->post_title, 0, 1 ) ) . '</span>';
		$out .= '<li class="carousel-item"><figure class="card t-card">' . ins_stars( $r ? $r : 5 ) . '<blockquote>' . wpautop( esc_html( wp_strip_all_tags( $p->post_content ) ) ) . '</blockquote><figcaption class="t-person">' . $img . '<span><strong>' . esc_html( $p->post_title ) . '</strong>' . ( $role ? '<small>' . esc_html( $role ) . '</small>' : '' ) . '</span></figcaption></figure></li>';
	}
	$out .= '</ul><div class="carousel-controls"><button type="button" class="car-btn" data-dir="-1" aria-label="Previous testimonials">' . ins_icon( 'arrow', 20, 'flip' ) . '</button><button type="button" class="car-btn" data-dir="1" aria-label="Next testimonials">' . ins_icon( 'arrow', 20 ) . '</button></div></div>';
	return $out;
}
add_shortcode( 'ins_testimonials', function () {
	return ins_render_testimonials();
} );

function ins_render_team() {
	$posts = get_posts( array( 'post_type' => 'ins_team', 'post_status' => 'publish', 'posts_per_page' => 12, 'no_found_rows' => true, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'ASC' ) ) );
	if ( ! $posts ) {
		return '';
	}
	$out = '<div class="team-grid">';
	foreach ( $posts as $p ) {
		$img  = has_post_thumbnail( $p->ID ) ? get_the_post_thumbnail( $p->ID, 'medium', array( 'loading' => 'lazy', 'alt' => esc_attr( $p->post_title ) ) ) : '<span class="team-init" aria-hidden="true">' . esc_html( mb_substr( $p->post_title, 0, 1 ) ) . '</span>';
		$role = get_post_meta( $p->ID, '_ins_role', true );
		$out .= '<article class="card team-card"><div class="team-photo">' . $img . '</div><h3>' . esc_html( $p->post_title ) . '</h3>' . ( $role ? '<p class="team-role">' . esc_html( $role ) . '</p>' : '' ) . '<p>' . esc_html( wp_trim_words( wp_strip_all_tags( $p->post_content ), 24 ) ) . '</p></article>';
	}
	return $out . '</div>';
}
add_shortcode( 'ins_team', 'ins_render_team' );

function ins_social_links() {
	$out = '';
	foreach ( array( 'facebook' => 'Facebook', 'instagram' => 'Instagram', 'x_twitter' => 'X (Twitter)', 'linkedin' => 'LinkedIn', 'youtube' => 'YouTube' ) as $k => $label ) {
		$u = ins_opt( $k );
		if ( $u ) {
			$out .= '<li><a href="' . esc_url( $u ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr( $label ) . '">' . ins_icon( $k, 20 ) . '</a></li>';
		}
	}
	return $out ? '<ul class="social">' . $out . '</ul>' : '';
}

/** Parse a product's meta into display lists. */
function ins_product_data( $id ) {
	$d = array();
	foreach ( array( 'benefits', 'features', 'coverage', 'eligibility', 'documents' ) as $k ) {
		$d[ $k ] = ins_lines( get_post_meta( $id, '_ins_' . $k, true ) );
	}
	$f = get_post_meta( $id, '_ins_faqs', true );
	$d['faqs'] = is_array( $f ) ? $f : array();
	return $d;
}
