<?php
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	$cap = 'manage_insurance_leads';
	global $wpdb;
	$new   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . ins_table() . " WHERE status = 'New'" ); // phpcs:ignore
	$badge = $new ? ' <span class="awaiting-mod">' . $new . '</span>' : '';
	add_menu_page( 'Insurance Leads', 'Insurance Leads' . $badge, $cap, 'ins-dashboard', 'ins_page_dashboard', 'dashicons-groups', 26 );
	add_submenu_page( 'ins-dashboard', 'Dashboard', 'Dashboard', $cap, 'ins-dashboard', 'ins_page_dashboard' );
	add_submenu_page( 'ins-dashboard', 'All Leads', 'All Leads', $cap, 'ins-leads', 'ins_page_leads' );
	add_submenu_page( 'ins-dashboard', 'Settings', 'Settings', 'manage_options', 'ins-settings', 'ins_page_settings' );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	$screen = get_current_screen();
	$ours   = false !== strpos( $hook, 'ins-' ) || ( $screen && in_array( $screen->post_type, array( 'insurance_product', 'ins_testimonial', 'ins_faq', 'ins_team' ), true ) );
	if ( ! $ours ) {
		return;
	}
	wp_enqueue_style( 'ins-admin', INS_URL . 'assets/admin.css', array(), INS_VER );
	wp_enqueue_script( 'ins-admin', INS_URL . 'assets/admin.js', array( 'jquery' ), INS_VER, true );
	if ( false !== strpos( $hook, 'ins-settings' ) ) {
		wp_enqueue_media();
	}
} );

function ins_status_badge( $s ) {
	return '<span class="ins-badge ins-badge--' . esc_attr( sanitize_title( $s ) ) . '"><i aria-hidden="true"></i>' . esc_html( $s ) . '</span>';
}

function ins_agents() {
	static $a = null;
	if ( null === $a ) {
		$a = array();
		foreach ( get_users( array( 'capability' => 'manage_insurance_leads', 'orderby' => 'display_name' ) ) as $u ) {
			$a[ $u->ID ] = $u->display_name;
		}
	}
	return $a;
}

/* ---------- Filters / queries ---------- */
function ins_filters() {
	$g = function ( $k ) {
		return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	};
	$f = array(
		's'         => $g( 's' ),
		'type'      => $g( 'type' ),
		'product'   => absint( $g( 'product' ) ),
		'status'    => $g( 'status' ),
		'agent'     => absint( $g( 'agent' ) ),
		'date_from' => $g( 'date_from' ),
		'date_to'   => $g( 'date_to' ),
		'orderby'   => $g( 'orderby' ) ? $g( 'orderby' ) : 'newest',
	);
	foreach ( array( 'date_from', 'date_to' ) as $k ) {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $f[ $k ] ) ) {
			$f[ $k ] = '';
		}
	}
	if ( ! in_array( $f['status'], ins_statuses(), true ) ) {
		$f['status'] = '';
	}
	if ( ! in_array( $f['orderby'], array( 'newest', 'oldest', 'updated' ), true ) ) {
		$f['orderby'] = 'newest';
	}
	return $f;
}

function ins_leads_where( $f ) {
	global $wpdb;
	$w = array( '1=1' );
	$a = array();
	if ( '' !== $f['s'] ) {
		$like = '%' . $wpdb->esc_like( $f['s'] ) . '%';
		$w[]  = '(full_name LIKE %s OR mobile LIKE %s OR email LIKE %s OR lead_code LIKE %s)';
		array_push( $a, $like, $like, $like, $like );
	}
	if ( '' !== $f['type'] ) {
		$w[] = 'insurance_type = %s';
		$a[] = $f['type'];
	}
	if ( $f['product'] ) {
		$w[] = 'product_id = %d';
		$a[] = $f['product'];
	}
	if ( '' !== $f['status'] ) {
		$w[] = 'status = %s';
		$a[] = $f['status'];
	}
	if ( $f['agent'] ) {
		$w[] = 'agent_id = %d';
		$a[] = $f['agent'];
	}
	if ( $f['date_from'] ) {
		$w[] = 'created_at >= %s';
		$a[] = $f['date_from'] . ' 00:00:00';
	}
	if ( $f['date_to'] ) {
		$w[] = 'created_at <= %s';
		$a[] = $f['date_to'] . ' 23:59:59';
	}
	return array( implode( ' AND ', $w ), $a );
}

function ins_leads_fetch( $f, $limit = 0, $offset = 0 ) {
	global $wpdb;
	list( $w, $a ) = ins_leads_where( $f );
	$order = array( 'newest' => 'created_at DESC, id DESC', 'oldest' => 'created_at ASC, id ASC', 'updated' => 'updated_at DESC, id DESC' );
	$sql   = 'SELECT * FROM ' . ins_table() . " WHERE $w ORDER BY " . $order[ $f['orderby'] ];
	if ( $limit ) {
		$sql .= ' LIMIT %d OFFSET %d';
		$a[]  = $limit;
		$a[]  = $offset;
	}
	return $wpdb->get_results( $a ? $wpdb->prepare( $sql, $a ) : $sql, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL
}

function ins_leads_count( $f ) {
	global $wpdb;
	list( $w, $a ) = ins_leads_where( $f );
	$sql = 'SELECT COUNT(*) FROM ' . ins_table() . " WHERE $w";
	return (int) $wpdb->get_var( $a ? $wpdb->prepare( $sql, $a ) : $sql ); // phpcs:ignore WordPress.DB.PreparedSQL
}

/* ---------- List page ---------- */
function ins_page_leads() {
	if ( ! current_user_can( 'manage_insurance_leads' ) ) {
		wp_die( 'You do not have permission to view leads.' );
	}
	if ( isset( $_GET['lead'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		ins_lead_view( absint( $_GET['lead'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	$f      = ins_filters();
	$per    = 20;
	$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
	$total  = ins_leads_count( $f );
	$rows   = ins_leads_fetch( $f, $per, ( $paged - 1 ) * $per );
	$opts   = ins_form_options();
	$base   = admin_url( 'admin.php?page=ins-leads' );
	$ex     = function ( $fmt ) use ( $f ) {
		return wp_nonce_url( add_query_arg( array_merge( array_filter( $f ), array( 'action' => 'ins_export', 'format' => $fmt ) ), admin_url( 'admin-post.php' ) ), 'ins_export' );
	};
	echo '<div class="wrap ins-wrap"><h1 class="wp-heading-inline">Insurance Leads</h1>';
	echo '<a class="page-title-action" href="' . esc_url( $ex( 'csv' ) ) . '">Export CSV</a> <a class="page-title-action" href="' . esc_url( $ex( 'xls' ) ) . '">Export Excel</a><hr class="wp-header-end">';
	if ( isset( $_GET['msg'] ) && 'deleted' === $_GET['msg'] ) { // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="notice notice-success is-dismissible"><p>Lead deleted.</p></div>';
	}
	echo '<p class="description">Exports respect the filters below. Leave filters empty to export all leads; use the date range to export a period.</p>';
	?>
	<form method="get" class="ins-filter">
		<input type="hidden" name="page" value="ins-leads">
		<input type="search" name="s" value="<?php echo esc_attr( $f['s'] ); ?>" placeholder="Name, mobile, email or Lead ID" aria-label="Search leads">
		<select name="type" aria-label="Insurance type"><option value="">All insurance types</option>
			<?php foreach ( $opts['cats'] as $c ) : ?>
				<option value="<?php echo esc_attr( $c['name'] ); ?>" <?php selected( $f['type'], $c['name'] ); ?>><?php echo esc_html( $c['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="product" aria-label="Product"><option value="">All products</option>
			<?php foreach ( $opts['prods'] as $p ) : ?>
				<option value="<?php echo (int) $p['id']; ?>" <?php selected( $f['product'], $p['id'] ); ?>><?php echo esc_html( $p['title'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="status" aria-label="Status"><option value="">All statuses</option>
			<?php foreach ( ins_statuses() as $s ) : ?>
				<option <?php selected( $f['status'], $s ); ?>><?php echo esc_html( $s ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="agent" aria-label="Assigned agent"><option value="">All agents</option>
			<?php foreach ( ins_agents() as $uid => $nm ) : ?>
				<option value="<?php echo (int) $uid; ?>" <?php selected( $f['agent'], $uid ); ?>><?php echo esc_html( $nm ); ?></option>
			<?php endforeach; ?>
		</select>
		<label>From <input type="date" name="date_from" value="<?php echo esc_attr( $f['date_from'] ); ?>"></label>
		<label>To <input type="date" name="date_to" value="<?php echo esc_attr( $f['date_to'] ); ?>"></label>
		<select name="orderby" aria-label="Sort">
			<option value="newest" <?php selected( $f['orderby'], 'newest' ); ?>>Newest</option>
			<option value="oldest" <?php selected( $f['orderby'], 'oldest' ); ?>>Oldest</option>
			<option value="updated" <?php selected( $f['orderby'], 'updated' ); ?>>Recently updated</option>
		</select>
		<button class="button button-primary">Filter</button>
		<a class="button" href="<?php echo esc_url( $base ); ?>">Reset</a>
	</form>
	<p><strong><?php echo (int) $total; ?></strong> lead<?php echo 1 === $total ? '' : 's'; ?> found</p>
	<div class="ins-scroll">
	<table class="wp-list-table widefat striped ins-table">
		<thead><tr><th>Lead ID</th><th>Date / time</th><th>Customer</th><th>Location</th><th>Insurance</th><th>Coverage / budget</th><th>Contact preference</th><th>Status</th><th>Agent</th><th>Updated</th></tr></thead>
		<tbody>
		<?php if ( ! $rows ) : ?>
			<tr><td colspan="10" class="ins-empty">No leads match your filters yet. Enquiries from the website form will appear here.</td></tr>
		<?php endif; ?>
		<?php
		$agents = ins_agents();
		foreach ( $rows as $r ) :
			$url = $base . '&lead=' . (int) $r['id'];
			?>
			<tr>
				<td><a href="<?php echo esc_url( $url ); ?>"><strong><?php echo esc_html( $r['lead_code'] ); ?></strong></a></td>
				<td><?php echo esc_html( mysql2date( 'd M Y', $r['created_at'] ) ); ?><br><small><?php echo esc_html( mysql2date( 'h:i A', $r['created_at'] ) ); ?></small></td>
				<td><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $r['full_name'] ); ?></a><br><small><a href="tel:<?php echo esc_attr( $r['mobile'] ); ?>"><?php echo esc_html( $r['mobile'] ); ?></a><br><?php echo esc_html( $r['email'] ); ?></small></td>
				<td><?php echo esc_html( $r['city'] ); ?><br><small><?php echo esc_html( $r['state'] ); ?></small></td>
				<td><?php echo esc_html( $r['insurance_type'] ); ?><br><small><?php echo esc_html( $r['product_name'] ); ?></small></td>
				<td><?php echo esc_html( $r['coverage'] ? $r['coverage'] : '-' ); ?><br><small><?php echo esc_html( $r['budget'] ? $r['budget'] : '-' ); ?></small></td>
				<td><?php echo esc_html( $r['contact_method'] ); ?><br><small><?php echo esc_html( $r['contact_time'] ); ?></small></td>
				<td><?php echo ins_status_badge( $r['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
				<td><?php echo esc_html( isset( $agents[ (int) $r['agent_id'] ] ) ? $agents[ (int) $r['agent_id'] ] : 'Unassigned' ); ?></td>
				<td><?php echo esc_html( mysql2date( 'd M, h:i A', $r['updated_at'] ) ); ?></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	</div>
	<?php
	$pages = (int) ceil( $total / $per );
	if ( $pages > 1 ) {
		echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $pages ) ) ) . '</div></div>';
	}
	echo '</div>';
}

/* ---------- Detail page ---------- */
function ins_lead_view( $id ) {
	global $wpdb;
	$l = ins_get_lead( $id );
	if ( ! $l ) {
		echo '<div class="wrap"><h1>Lead not found</h1><p><a href="' . esc_url( admin_url( 'admin.php?page=ins-leads' ) ) . '">Back to leads</a></p></div>';
		return;
	}
	$hist = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . ins_table( 'history' ) . ' WHERE lead_id = %d ORDER BY id ASC', $id ), ARRAY_A ); // phpcs:ignore
	$opts = ins_form_options();
	$f    = function ( $name, $label, $type = 'text' ) use ( $l ) {
		echo '<p><label><span class="ins-lbl">' . esc_html( $label ) . '</span><input class="widefat" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $l[ $name ] ) . '"></label></p>';
	};
	$stage_map = array( 'New' => 0, 'Contacted' => 1, 'Follow-up' => 2, 'Interested' => 2, 'Converted' => 3 );
	$stages    = array( 'Enquiry Received', 'Contacted', 'Follow-up', 'Converted' );
	$at        = isset( $stage_map[ $l['status'] ] ) ? $stage_map[ $l['status'] ] : -1;
	?>
	<div class="wrap ins-wrap">
		<h1 class="wp-heading-inline"><?php echo esc_html( $l['lead_code'] ); ?>: <?php echo esc_html( $l['full_name'] ); ?></h1>
		<a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=ins-leads' ) ); ?>">Back to all leads</a><hr class="wp-header-end">
		<?php if ( isset( $_GET['msg'] ) && 'saved' === $_GET['msg'] ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice notice-success is-dismissible"><p>Lead updated.</p></div>
		<?php endif; ?>

		<ol class="ins-timeline" aria-label="Lead progress">
			<?php foreach ( $stages as $i => $s ) : ?>
				<li class="<?php echo $i < $at ? 'is-done' : ( $i === $at ? 'is-current' : '' ); ?>"><span><?php echo esc_html( $s ); ?></span></li>
			<?php endforeach; ?>
		</ol>
		<?php if ( $at < 0 ) : ?><p>Current status: <?php echo ins_status_badge( $l['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></p><?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ins-detail">
			<input type="hidden" name="action" value="ins_save_lead">
			<input type="hidden" name="lead_id" value="<?php echo (int) $id; ?>">
			<?php wp_nonce_field( 'ins_save_lead_' . $id ); ?>

			<div class="ins-panel">
				<h2>Manage lead</h2>
				<p><label><span class="ins-lbl">Status</span><select name="status" class="widefat"><?php foreach ( ins_statuses() as $s ) : ?><option <?php selected( $l['status'], $s ); ?>><?php echo esc_html( $s ); ?></option><?php endforeach; ?></select></label></p>
				<p><label><span class="ins-lbl">Assigned agent</span><select name="agent_id" class="widefat"><option value="0">Unassigned</option><?php foreach ( ins_agents() as $uid => $nm ) : ?><option value="<?php echo (int) $uid; ?>" <?php selected( (int) $l['agent_id'], $uid ); ?>><?php echo esc_html( $nm ); ?></option><?php endforeach; ?></select></label></p>
				<p><label><span class="ins-lbl">Follow-up date</span><input type="date" class="widefat" name="followup_date" value="<?php echo esc_attr( (string) $l['followup_date'] ); ?>"></label></p>
				<p><label><span class="ins-lbl">Add a note</span><textarea class="widefat" rows="3" name="new_note" placeholder="e.g. Called, asked to call back after 6 pm"></textarea></label></p>
				<?php if ( $l['notes'] ) : ?><div class="ins-notes"><strong>Admin notes</strong><pre><?php echo esc_html( $l['notes'] ); ?></pre></div><?php endif; ?>
			</div>

			<div class="ins-panel">
				<h2>Customer information</h2>
				<div class="ins-cols">
					<div>
						<?php $f( 'full_name', 'Full name' ); $f( 'mobile', 'Mobile', 'tel' ); $f( 'email', 'Email', 'email' ); $f( 'dob', 'Date of birth', 'date' ); $f( 'gender', 'Gender' ); ?>
					</div>
					<div>
						<?php $f( 'city', 'City' ); $f( 'state', 'State' ); $f( 'pincode', 'Pincode' ); $f( 'coverage', 'Coverage required' ); $f( 'budget', 'Approximate budget' ); ?>
					</div>
					<div>
						<p><label><span class="ins-lbl">Insurance type</span><select name="insurance_type" class="widefat"><option value=""></option><?php foreach ( $opts['cats'] as $c ) : ?><option <?php selected( $l['insurance_type'], $c['name'] ); ?>><?php echo esc_html( $c['name'] ); ?></option><?php endforeach; ?></select></label></p>
						<p><label><span class="ins-lbl">Insurance product</span><select name="product_id" class="widefat"><option value="0"></option><?php foreach ( $opts['prods'] as $p ) : ?><option value="<?php echo (int) $p['id']; ?>" <?php selected( (int) $l['product_id'], $p['id'] ); ?>><?php echo esc_html( $p['title'] ); ?></option><?php endforeach; ?></select></label></p>
						<?php $f( 'existing_policy', 'Existing policy' ); $f( 'policy_number', 'Policy number' ); $f( 'contact_method', 'Preferred contact method' ); $f( 'contact_time', 'Preferred contact time' ); ?>
					</div>
				</div>
				<p><strong>Customer message</strong></p>
				<p class="ins-msg"><?php echo $l['message'] ? nl2br( esc_html( $l['message'] ) ) : '<em>No message.</em>'; // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
				<p class="description">Received <?php echo esc_html( mysql2date( 'd M Y, h:i A', $l['created_at'] ) ); ?> from <?php echo esc_html( $l['source_url'] ? $l['source_url'] : 'the website' ); ?></p>
			</div>
			<p><button class="button button-primary button-large">Save changes</button></p>
		</form>

		<div class="ins-panel">
			<h2>Enquiry history</h2>
			<ul class="ins-history">
				<?php foreach ( $hist as $h ) : $u = $h['user_id'] ? get_userdata( (int) $h['user_id'] ) : false; ?>
					<li><time><?php echo esc_html( mysql2date( 'd M Y, h:i A', $h['created_at'] ) ); ?></time> <strong><?php echo esc_html( $h['event'] ); ?></strong><?php echo $u ? ' <em>by ' . esc_html( $u->display_name ) . '</em>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo $h['detail'] ? '<br><span>' . esc_html( $h['detail'] ) . '</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?></li>
				<?php endforeach; ?>
			</ul>
		</div>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Delete this lead permanently?');">
			<input type="hidden" name="action" value="ins_delete_lead">
			<input type="hidden" name="lead_id" value="<?php echo (int) $id; ?>">
			<?php wp_nonce_field( 'ins_delete_lead_' . $id ); ?>
			<button class="button button-link-delete">Delete this lead</button>
		</form>
	</div>
	<?php
}

add_action( 'admin_post_ins_save_lead', function () {
	if ( ! current_user_can( 'manage_insurance_leads' ) ) {
		wp_die( 'Forbidden', 403 );
	}
	global $wpdb;
	$id = isset( $_POST['lead_id'] ) ? absint( $_POST['lead_id'] ) : 0;
	check_admin_referer( 'ins_save_lead_' . $id );
	$old = ins_get_lead( $id );
	if ( ! $old ) {
		wp_die( 'Lead not found.' );
	}
	$g = function ( $k ) {
		return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	};
	$new = array();
	foreach ( array( 'full_name', 'mobile', 'city', 'state', 'pincode', 'gender', 'coverage', 'budget', 'existing_policy', 'policy_number', 'contact_method', 'contact_time', 'insurance_type' ) as $k ) {
		$new[ $k ] = $g( $k );
	}
	$new['email'] = sanitize_email( $g( 'email' ) );
	$dob          = $g( 'dob' );
	$new['dob']   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $dob ) ? $dob : null;
	$fu           = $g( 'followup_date' );
	$new['followup_date'] = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $fu ) ? $fu : null;
	$status       = $g( 'status' );
	$new['status'] = in_array( $status, ins_statuses(), true ) ? $status : $old['status'];
	$agent        = absint( $g( 'agent_id' ) );
	$new['agent_id'] = ( 0 === $agent || isset( ins_agents()[ $agent ] ) ) ? $agent : (int) $old['agent_id'];
	$pid          = absint( $g( 'product_id' ) );
	$new['product_id']   = ( $pid && 'insurance_product' === get_post_type( $pid ) ) ? $pid : 0;
	$new['product_name'] = $new['product_id'] ? get_the_title( $pid ) : '';
	if ( ! is_email( $new['email'] ) ) {
		$new['email'] = $old['email'];
	}
	$note = isset( $_POST['new_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['new_note'] ) ) : '';
	if ( '' !== $note ) {
		$u            = wp_get_current_user();
		$stamp        = '[' . current_time( 'd M Y, h:i A' ) . ' - ' . $u->display_name . '] ';
		$new['notes'] = $stamp . $note . ( $old['notes'] ? "\n\n" . $old['notes'] : '' );
		ins_log( $id, 'Note added', $note );
	}
	$new['updated_at'] = current_time( 'mysql' );
	$wpdb->update( ins_table(), $new, array( 'id' => $id ) );

	if ( $new['status'] !== $old['status'] ) {
		ins_log( $id, $new['status'], 'Status changed from ' . $old['status'] . ' to ' . $new['status'] . '.' );
	}
	if ( (int) $new['agent_id'] !== (int) $old['agent_id'] ) {
		$ag = ins_agents();
		ins_log( $id, 'Agent assigned', $new['agent_id'] ? $ag[ $new['agent_id'] ] : 'Unassigned' );
	}
	if ( (string) $new['followup_date'] !== (string) $old['followup_date'] ) {
		ins_log( $id, 'Follow-up scheduled', $new['followup_date'] ? $new['followup_date'] : 'Cleared' );
	}
	$changed = array();
	foreach ( array( 'full_name', 'mobile', 'email', 'city', 'state', 'pincode', 'gender', 'dob', 'coverage', 'budget', 'insurance_type', 'product_id', 'existing_policy', 'policy_number', 'contact_method', 'contact_time' ) as $k ) {
		if ( (string) $new[ $k ] !== (string) $old[ $k ] ) {
			$changed[] = $k;
		}
	}
	if ( $changed ) {
		ins_log( $id, 'Customer information updated', implode( ', ', $changed ) );
	}
	wp_safe_redirect( admin_url( 'admin.php?page=ins-leads&lead=' . $id . '&msg=saved' ) );
	exit;
} );

add_action( 'admin_post_ins_delete_lead', function () {
	if ( ! current_user_can( 'manage_insurance_leads' ) ) {
		wp_die( 'Forbidden', 403 );
	}
	global $wpdb;
	$id = isset( $_POST['lead_id'] ) ? absint( $_POST['lead_id'] ) : 0;
	check_admin_referer( 'ins_delete_lead_' . $id );
	$wpdb->delete( ins_table(), array( 'id' => $id ) );
	$wpdb->delete( ins_table( 'history' ), array( 'lead_id' => $id ) );
	wp_safe_redirect( admin_url( 'admin.php?page=ins-leads&msg=deleted' ) );
	exit;
} );
