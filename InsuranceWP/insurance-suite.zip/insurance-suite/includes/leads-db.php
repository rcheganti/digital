<?php
defined( 'ABSPATH' ) || exit;

function ins_table( $name = 'leads' ) {
	global $wpdb;
	return $wpdb->prefix . 'ins_' . $name;
}

function ins_install_db() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$c = $wpdb->get_charset_collate();
	$t = ins_table( 'leads' );
	$h = ins_table( 'history' );
	dbDelta( "CREATE TABLE $t (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  lead_code varchar(24) NOT NULL DEFAULT '',
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  full_name varchar(150) NOT NULL DEFAULT '',
  mobile varchar(15) NOT NULL DEFAULT '',
  email varchar(190) NOT NULL DEFAULT '',
  dob date DEFAULT NULL,
  gender varchar(20) NOT NULL DEFAULT '',
  city varchar(100) NOT NULL DEFAULT '',
  state varchar(100) NOT NULL DEFAULT '',
  pincode varchar(10) NOT NULL DEFAULT '',
  insurance_type varchar(120) NOT NULL DEFAULT '',
  product_id bigint(20) unsigned NOT NULL DEFAULT 0,
  product_name varchar(190) NOT NULL DEFAULT '',
  existing_policy varchar(5) NOT NULL DEFAULT '',
  policy_number varchar(80) NOT NULL DEFAULT '',
  coverage varchar(100) NOT NULL DEFAULT '',
  budget varchar(100) NOT NULL DEFAULT '',
  contact_method varchar(30) NOT NULL DEFAULT '',
  contact_time varchar(40) NOT NULL DEFAULT '',
  message text,
  consent tinyint(1) NOT NULL DEFAULT 0,
  status varchar(30) NOT NULL DEFAULT 'New',
  agent_id bigint(20) unsigned NOT NULL DEFAULT 0,
  notes longtext,
  followup_date date DEFAULT NULL,
  source_url varchar(255) NOT NULL DEFAULT '',
  ip_hash varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY  (id),
  UNIQUE KEY lead_code (lead_code),
  KEY status (status),
  KEY created_at (created_at),
  KEY mobile (mobile),
  KEY agent_id (agent_id)
) $c;" );
	dbDelta( "CREATE TABLE $h (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  lead_id bigint(20) unsigned NOT NULL,
  created_at datetime NOT NULL,
  user_id bigint(20) unsigned NOT NULL DEFAULT 0,
  event varchar(80) NOT NULL DEFAULT '',
  detail text,
  PRIMARY KEY  (id),
  KEY lead_id (lead_id)
) $c;" );
}

function ins_log( $lead_id, $event, $detail = '' ) {
	global $wpdb;
	$wpdb->insert( ins_table( 'history' ), array(
		'lead_id'    => (int) $lead_id,
		'created_at' => current_time( 'mysql' ),
		'user_id'    => get_current_user_id(),
		'event'      => $event,
		'detail'     => $detail,
	) );
}

/** Insert a lead; returns the lead row (array) or false. */
function ins_insert_lead( array $d ) {
	global $wpdb;
	$now = current_time( 'mysql' );
	$row = array_merge( $d, array(
		'lead_code'  => 'tmp' . wp_generate_password( 14, false ),
		'created_at' => $now,
		'updated_at' => $now,
		'status'     => 'New',
	) );
	if ( ! $wpdb->insert( ins_table(), $row ) ) {
		return false;
	}
	$id   = (int) $wpdb->insert_id;
	$code = 'INS-' . ( 10000 + $id );
	$wpdb->update( ins_table(), array( 'lead_code' => $code ), array( 'id' => $id ) );
	ins_log( $id, 'Enquiry Received', 'Submitted from the website form.' );
	return ins_get_lead( $id );
}

function ins_get_lead( $id ) {
	global $wpdb;
	return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . ins_table() . ' WHERE id = %d', $id ), ARRAY_A );
}
