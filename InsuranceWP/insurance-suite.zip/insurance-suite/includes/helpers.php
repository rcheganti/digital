<?php
defined( 'ABSPATH' ) || exit;

/** Default values for every setting on the Settings page. */
function ins_defaults() {
	return array(
		'company_name'     => 'SecureShield Insurance',
		'tagline'          => 'Insurance advisors you can trust',
		'logo'             => 0,
		'favicon'          => 0,
		'cta_text'         => 'Get a Free Quote',
		'phone'            => '+91 98765 43210',
		'whatsapp'         => '919876543210',
		'email'            => 'hello@example.com',
		'address'          => "12, Business Park, Hitech City\nHyderabad, Telangana 500081",
		'hours'            => "Mon to Sat: 9:00 AM to 7:00 PM\nSunday: Closed",
		'facebook'         => '',
		'instagram'        => '',
		'x_twitter'        => '',
		'linkedin'         => '',
		'youtube'          => '',
		'hero_title'       => 'Protect What Matters Most',
		'hero_text'        => 'Simple, reliable and affordable insurance solutions designed around your needs.',
		'stat1_value'      => '10K+',
		'stat1_label'      => 'Customers',
		'stat2_value'      => '25+',
		'stat2_label'      => 'Insurance Plans',
		'stat3_value'      => '15+',
		'stat3_label'      => 'Years Experience',
		'stat4_value'      => '98%',
		'stat4_label'      => 'Customer Satisfaction',
		'about_intro'      => 'We are an independent insurance advisory team that helps families, professionals and business owners choose cover that genuinely fits. We compare plans from leading insurers, explain the fine print in plain language and stay with you at claim time.',
		'mission'          => 'To make insurance simple, transparent and accessible so every family can protect what matters most without confusion or pressure.',
		'vision'           => 'To be the most trusted insurance guidance partner in the country, known for honest advice and fast, caring service.',
		'footer_text'      => 'We help individuals, families and businesses find the right insurance cover with honest advice and zero pressure.',
		'notification_email' => get_option( 'admin_email' ),
		'admin_subject'    => 'New insurance enquiry {lead_id} from {name}',
		'admin_body'       => "A new enquiry has been received.\n\nLead ID: {lead_id}\nName: {name}\nMobile: {mobile}\nEmail: {email}\nCity: {city}, {state}\nInsurance: {insurance_type} / {product}\nCoverage: {coverage}\nBudget: {budget}\nPreferred contact: {contact_method} ({contact_time})\nMessage: {message}\n\nOpen in dashboard: {admin_url}",
		'customer_subject' => 'We received your enquiry {lead_id} | {company}',
		'customer_body'    => "Hi {name},\n\nThank you for contacting {company}. Your enquiry ID is {lead_id} for {product}.\n\nOur insurance advisor will contact you shortly via {contact_method}.\n\nRegards,\n{company}\n{phone}",
		'turnstile_site'   => '',
		'turnstile_secret' => '',
	);
}

/** Read one setting. */
function ins_opt( $key, $default = '' ) {
	static $opts = null;
	if ( null === $opts ) {
		$opts = wp_parse_args( (array) get_option( 'ins_settings', array() ), ins_defaults() );
	}
	return ( isset( $opts[ $key ] ) && '' !== $opts[ $key ] ) ? $opts[ $key ] : $default;
}

function ins_statuses() {
	return array( 'New', 'Contacted', 'Follow-up', 'Interested', 'Converted', 'Not Interested', 'Closed' );
}

function ins_states() {
	return array( 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Jammu and Kashmir', 'Ladakh', 'Lakshadweep', 'Puducherry' );
}

/** Split a textarea into clean lines. */
function ins_lines( $text ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) $text ) ) ) );
}

function ins_wa_number() {
	return preg_replace( '/\D/', '', (string) ins_opt( 'whatsapp' ) );
}

function ins_tel() {
	return 'tel:' . preg_replace( '/[^\d+]/', '', (string) ins_opt( 'phone' ) );
}

/** URL of the quote page, optionally pre-selecting a product / insurance type. */
function ins_quote_url( $product = 0, $type = '' ) {
	$page = get_page_by_path( 'get-quote' );
	$url  = $page ? get_permalink( $page ) : home_url( '/get-quote/' );
	$args = array();
	if ( $product ) {
		$args['product'] = (int) $product;
	}
	if ( $type ) {
		$args['type'] = $type;
	}
	return $args ? add_query_arg( $args, $url ) : $url;
}

/** Cached categories + products used by the enquiry form dropdowns. */
function ins_form_options() {
	$data = get_transient( 'ins_form_opts' );
	if ( false !== $data ) {
		return $data;
	}
	$cats = get_terms( array( 'taxonomy' => 'insurance_category', 'hide_empty' => false ) );
	$cats = is_wp_error( $cats ) ? array() : $cats;
	$out  = array( 'cats' => array(), 'prods' => array() );
	foreach ( $cats as $c ) {
		$out['cats'][] = array( 'slug' => $c->slug, 'name' => $c->name );
	}
	$ids = get_posts( array( 'post_type' => 'insurance_product', 'post_status' => 'publish', 'numberposts' => 200, 'orderby' => 'title', 'order' => 'ASC', 'fields' => 'ids' ) );
	foreach ( $ids as $id ) {
		$slugs = wp_get_post_terms( $id, 'insurance_category', array( 'fields' => 'slugs' ) );
		$out['prods'][] = array( 'id' => $id, 'title' => get_the_title( $id ), 'cats' => is_wp_error( $slugs ) ? array() : $slugs );
	}
	set_transient( 'ins_form_opts', $out, 12 * HOUR_IN_SECONDS );
	return $out;
}
function ins_flush_form_cache() {
	delete_transient( 'ins_form_opts' );
}
add_action( 'save_post_insurance_product', 'ins_flush_form_cache' );
add_action( 'deleted_post', 'ins_flush_form_cache' );
add_action( 'trashed_post', 'ins_flush_form_cache' );
add_action( 'untrashed_post', 'ins_flush_form_cache' );
add_action( 'created_insurance_category', 'ins_flush_form_cache' );
add_action( 'edited_insurance_category', 'ins_flush_form_cache' );
add_action( 'delete_insurance_category', 'ins_flush_form_cache' );

/** Roles: administrators and a new "Insurance Agent" role can manage leads. */
function ins_add_roles() {
	$admin = get_role( 'administrator' );
	if ( $admin ) {
		$admin->add_cap( 'manage_insurance_leads' );
	}
	if ( ! get_role( 'insurance_agent' ) ) {
		add_role( 'insurance_agent', 'Insurance Agent', array( 'read' => true, 'manage_insurance_leads' => true ) );
	}
}

/** Inline SVG icon set (stroke icons, 24x24). */
function ins_icon( $name, $size = 24, $class = '' ) {
	static $p = null;
	if ( null === $p ) {
		$p = array(
			'shield'       => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
			'shield-check' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
			'heart'        => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
			'umbrella'     => '<path d="M22 12a10 10 0 0 0-20 0z"/><path d="M12 12v7a2 2 0 0 0 4 0"/>',
			'car'          => '<path d="M3 13l2-6a2 2 0 0 1 2-1.5h10A2 2 0 0 1 19 7l2 6v4a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-1H7v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M3 13h18"/><circle cx="7.5" cy="15.5" r=".6"/><circle cx="16.5" cy="15.5" r=".6"/>',
			'bike'         => '<circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/><path d="M15 6h3l-3 11.5M5.5 17.5 9 9h6M9 9 7 6H5"/>',
			'plane'        => '<path d="M17.8 19.2 16 11l3.5-3.5a2.1 2.1 0 0 0-3-3L13 8 4.8 6.2 3.4 7.6l6.3 3.6-3 3-3-.5-1 1 4 2 2 4 1-1-.5-3 3-3 3.6 6.3z"/>',
			'home'         => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
			'briefcase'    => '<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2M2 13h20"/>',
			'check'        => '<path d="M20 6 9 17l-5-5"/>',
			'phone'        => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
			'mail'         => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
			'pin'          => '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
			'clock'        => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
			'users'        => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
			'star'         => '<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/>',
			'arrow'        => '<path d="M5 12h14M13 6l6 6-6 6"/>',
			'menu'         => '<path d="M4 6h16M4 12h16M4 18h16"/>',
			'x'            => '<path d="M18 6 6 18M6 6l12 12"/>',
			'chevron'      => '<path d="m6 9 6 6 6-6"/>',
			'file'         => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
			'headset'      => '<path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1v-6h3zM3 19a2 2 0 0 0 2 2h1v-6H3z"/>',
			'zap'          => '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
			'eye'          => '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
			'layers'       => '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
			'lock'         => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
			'whatsapp'     => '<path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 20.5l1.6-5.4A8.4 8.4 0 1 1 21 11.5z"/><path d="M8.5 9.5c0 3 3 6 6 6l1.3-1.3-2-1-1 .6a4 4 0 0 1-1.8-1.8l.6-1-1-2z"/>',
			'facebook'     => '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
			'instagram'    => '<rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/>',
			'linkedin'     => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/>',
			'youtube'      => '<path d="M22.5 6.4a2.8 2.8 0 0 0-2-2C18.8 4 12 4 12 4s-6.8 0-8.5.4a2.8 2.8 0 0 0-2 2C1 8.1 1 12 1 12s0 3.9.5 5.6a2.8 2.8 0 0 0 2 2C5.2 20 12 20 12 20s6.8 0 8.5-.4a2.8 2.8 0 0 0 2-2c.5-1.7.5-5.6.5-5.6s0-3.9-.5-5.6z"/><path d="m10 15 5-3-5-3z"/>',
			'x_twitter'    => '<path d="M4 4l16 16M20 4 4 20"/>',
		);
	}
	if ( ! isset( $p[ $name ] ) ) {
		$name = 'shield';
	}
	return '<svg class="icon ' . esc_attr( $class ) . '" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $p[ $name ] . '</svg>';
}

/** Choose an icon for a category slug. */
function ins_category_icon( $slug ) {
	$map = array( 'health' => 'heart', 'life' => 'umbrella', 'term' => 'shield-check', 'two' => 'bike', 'bike' => 'bike', 'motor' => 'car', 'car' => 'car', 'travel' => 'plane', 'home' => 'home', 'business' => 'briefcase' );
	foreach ( $map as $needle => $icon ) {
		if ( false !== strpos( (string) $slug, $needle ) ) {
			return $icon;
		}
	}
	return 'shield';
}
