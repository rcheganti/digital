<?php
defined( 'ABSPATH' ) || exit;

function ins_export_columns() {
	return array(
		'lead_code' => 'Lead ID', 'created_at' => 'Date & Time', 'full_name' => 'Customer Name', 'mobile' => 'Mobile', 'email' => 'Email', 'dob' => 'Date of Birth', 'gender' => 'Gender',
		'city' => 'City', 'state' => 'State', 'pincode' => 'Pincode', 'insurance_type' => 'Insurance Type', 'product_name' => 'Insurance Product', 'existing_policy' => 'Existing Policy',
		'policy_number' => 'Policy Number', 'coverage' => 'Coverage', 'budget' => 'Budget', 'contact_method' => 'Preferred Contact Method', 'contact_time' => 'Preferred Contact Time',
		'message' => 'Message', 'status' => 'Status', 'agent' => 'Assigned Agent', 'followup_date' => 'Follow-up Date', 'notes' => 'Admin Notes', 'updated_at' => 'Last Updated',
	);
}

add_action( 'admin_post_ins_export', function () {
	if ( ! current_user_can( 'manage_insurance_leads' ) ) {
		wp_die( 'Forbidden', 403 );
	}
	check_admin_referer( 'ins_export' );
	$f      = ins_filters();
	$rows   = ins_leads_fetch( $f );
	$cols   = ins_export_columns();
	$agents = ins_agents();
	$fmt    = ( isset( $_GET['format'] ) && 'xls' === $_GET['format'] ) ? 'xls' : 'csv';
	$name   = 'insurance-leads-' . gmdate( 'Y-m-d-His' ) . '.' . $fmt;

	$cell = function ( $row, $key ) use ( $agents ) {
		if ( 'agent' === $key ) {
			$v = isset( $agents[ (int) $row['agent_id'] ] ) ? $agents[ (int) $row['agent_id'] ] : 'Unassigned';
		} else {
			$v = (string) $row[ $key ];
		}
		// Neutralise spreadsheet formula injection.
		if ( '' !== $v && in_array( $v[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			$v = "'" . $v;
		}
		return $v;
	};

	nocache_headers();
	if ( 'csv' === $fmt ) {
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array_values( $cols ) );
		foreach ( $rows as $r ) {
			$line = array();
			foreach ( array_keys( $cols ) as $k ) {
				$line[] = $cell( $r, $k );
			}
			fputcsv( $out, $line );
		}
		fclose( $out );
		exit;
	}
	// Excel (SpreadsheetML 2003) opens natively in Excel / LibreOffice / Google Sheets.
	header( 'Content-Type: application/vnd.ms-excel; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename="' . $name . '"' );
	$x = function ( $v ) {
		return htmlspecialchars( (string) $v, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
	};
	echo '<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>'; // phpcs:ignore
	echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Styles><Style ss:ID="h"><Font ss:Bold="1"/></Style></Styles><Worksheet ss:Name="Leads"><Table><Row>'; // phpcs:ignore
	foreach ( $cols as $label ) {
		echo '<Cell ss:StyleID="h"><Data ss:Type="String">' . $x( $label ) . '</Data></Cell>'; // phpcs:ignore
	}
	echo '</Row>';
	foreach ( $rows as $r ) {
		echo '<Row>';
		foreach ( array_keys( $cols ) as $k ) {
			echo '<Cell><Data ss:Type="String">' . $x( $cell( $r, $k ) ) . '</Data></Cell>'; // phpcs:ignore
		}
		echo '</Row>';
	}
	echo '</Table></Worksheet></Workbook>';
	exit;
} );
