# SoRaHub WordPress Starter Package

This ZIP contains:
- `wp-content/themes/sorahub-real-estate/` — responsive starter WordPress theme
- `wp-content/plugins/sorahub-property-leads/` — property listings, basic property fields, enquiry capture, and lead records

## Important
This is a starter implementation, not a finished or production-audited website. It has not been installed on your hosting account or tested against your specific WordPress environment. Test on a staging site first, configure backups/SMTP/security, and verify all workflows before launch.

## Installation
1. Back up your current WordPress site (if any).
2. In WordPress, go to **Plugins → Add New Plugin → Upload Plugin** and upload `sorahub-property-leads.zip` (included separately inside this package folder only after you zip the plugin directory), or upload the plugin folder to `wp-content/plugins/` using your host's File Manager/SFTP.
3. Activate **SoRaHub Property & Leads**.
4. Upload the theme via **Appearance → Themes → Add New Theme → Upload Theme**, or upload the theme folder to `wp-content/themes/`.
5. Activate **SoRaHub Real Estate**.
6. Go to **Settings → Permalinks** and click **Save Changes** once to refresh property URLs.
7. Go to **Properties → Add New Property**. Add a title, description, Featured Image, and property details. Publish the property.
8. Create pages for About Us and Contact Us and add your verified company details.
9. Set the homepage under **Settings → Reading** to a static page if you create a separate homepage page. The theme's front-page template is used when WordPress is configured with a static front page.
10. Configure reliable SMTP email delivery and test a lead form.
11. Create a WordPress navigation menu under **Appearance → Menus** and assign it to **Primary Menu**.

## Shortcodes
- `[sorahub_property_search]` — property search form
- `[sorahub_properties count="6"]` — property grid
- `[sorahub_lead_form]` — enquiry form (automatically links the current property on property pages)
- `[sorahub_lead_form property_id="123"]` — enquiry form associated with property ID 123

## Property management
The plugin adds a **Properties** menu. Add the main image through **Featured Image** and enter price, type, listing type, location, bedrooms, bathrooms, area, status, furnishing, and amenities in the SoRaHub Property Details box.

The current starter supports gallery attachment IDs as a comma-separated field. A future improvement would be a media-library picker.

## Lead management
The plugin adds a **Leads** menu. Website enquiries are saved as private lead records. Open a lead to review customer details and update status, priority, follow-up date, assignee, and internal notes. An administrator-level CSV export link is provided in the WordPress admin.

## Before public launch
- Replace placeholder text with verified SoRaHub business details.
- Configure SMTP and verify notification delivery.
- Configure privacy policy and consent language for your jurisdiction.
- Review access roles carefully; use least-privilege access.
- Test form submissions, spam handling, property search, CSV export, mobile layouts, backups, and email delivery.
- Add CAPTCHA/rate limiting and duplicate lead review workflow if needed.
- Configure SEO plugin, Search Console, analytics, caching, image optimization, and redirects.
- Check all plugin/theme compatibility and run security/performance audits.

## Current limitations
This starter is intentionally plugin-light. It does not yet include a complete CRM-grade saved-view system, automatic duplicate detection, calendar-integrated reminders, sales-agent assignment notifications, advanced reports, map search, or WhatsApp Business API integration. Those require compatible plugins, third-party services, or additional development. Do not assume these are active until implemented and tested.
